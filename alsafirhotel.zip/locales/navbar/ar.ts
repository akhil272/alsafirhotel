export default {
  offers: "عروض",
  dine: "تناول العشاء",
  stay: "البقاء",
  entertainment: "تسلية",
  meet: "لقاء وحدث",
  health: "الصحة والعافية",
  photogallery: "معرض الصور",
  blog: "مقالات",
  brandstory: "قصة العلامة التجارية",
};
