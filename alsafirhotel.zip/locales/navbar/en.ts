export default {
  offers: "offers",
  dine: "dine",
  stay: "stay",
  entertainment: "entertainment",
  meet: "meet & event",
  health: "health & wellness",
  photogallery: "photo gallery",
  blog: "blog",
  brandstory: "brand story",
};
