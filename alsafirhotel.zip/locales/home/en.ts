export default {
  subtitle: "Towers Residence Fitness",
  hero: "AL SAFIR HOTEL",
  location: "Manama, Bahrain",
  p1: `It is said that absolute luxury vests in minute particulars to give a heavenly experience. It involves competitive vision, ages preparing a craft and building reputation. Luxurious experience becomes a bequest. Al Safir, manifests a legacy in itself with the motive “service before self”. We take at most care and are upright for our customer service. This is the exact place where you experience paths of “Safirness”, a promise to make you lose your way and yet, find yourself to an unforgettable memory around the corner. The motivation for our customer service is our commitment to personal care and attention which you often find visiting friends and family. Relax your mind with stunning views, with the beauty of discovery, find the flow out of the beaches and fill your bags with luxury brand shopping.`,
  p2: "If you are looking for a royal stay then Al Safir Hotel is the place for you. The hotel assures you unbending comfort and convenience of a modern extravagant hotel without any compromise of its rare significant character. It is a gateway to a magnificent place located in right in Manama’s Juffair district, lllll. Adding to that, we offer exotic experience, soothing hospitality and a royal stay.Don’t blink twice to book because you deserve the best!",
};
