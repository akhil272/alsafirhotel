export default {
  title: "احجز غرفتك",
  room: "غرف",
  adult: "الكبار",
  children: "أطفال",
  startdate: "تاريخ البدء",
  enddate: "تاريخ الانتهاء",
  booknow: "احجز الآن",
  deluxtwin: "ديلوكس توأم",
  deluxsingle: "ديلوكس مفرد",
};
