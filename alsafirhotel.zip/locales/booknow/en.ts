export default {
  title: "BOOK YOUR ROOM",
  room: "Room",
  adult: "Adults",
  children: "Children",
  startdate: "Start Date",
  enddate: "End Date",
  booknow: "Book Now",
  deluxtwin: "Deluxe Twin",
  deluxsingle: "Deluxe Single",
};
