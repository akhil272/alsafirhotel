"use strict";
exports.id = 23;
exports.ids = [23];
exports.modules = {

/***/ 5023:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5282);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);



const alsfairLogo = /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("svg", {
  xmlns: "http://www.w3.org/2000/svg",
  width: "146",
  height: "50",
  fill: "none",
  viewBox: "0 0 146 50",
  children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
    fill: "#C4A47E",
    fillRule: "evenodd",
    d: "M85.232 38.804h1.574v-14.43h2.744c1.324 0 2.118.113 3.065.605 1.017.52 1.714 1.8 1.714 3.052 0 1.406-.878 2.87-2.591 3.361-.697.211-1.38.24-3.372.24l5.336 7.187h1.978l-4.43-5.922c3.037-.197 4.68-2.531 4.68-4.824 0-1.955-1.044-3.685-2.8-4.529-.724-.351-1.769-.605-3.872-.605H85.26v15.865h-.028zm-6.255 0h1.574V22.94h-1.575v15.865zm-12.037 0h1.574v-7.243h6.144v-1.434h-6.144v-5.753h6.38V22.94h-7.94v15.864h-.014zM55.99 24.74l3.023 7.285h-6.102l3.079-7.285zm-7.593 14.064h1.63l2.299-5.33h7.3l2.27 5.33h1.728L56.868 22.94h-1.77l-6.7 15.865zm-11.967-4.43c.07 3.502 2.815 4.712 4.848 4.712 2.787 0 4.737-2.208 4.737-4.656 0-.464.014-3.544-3.845-4.585-2.062-.604-3.734-1.055-3.734-2.981 0-1.379 1.045-2.771 2.842-2.771 1.491 0 2.787 1.266 2.787 2.869h1.574c0-2.32-1.783-4.318-4.347-4.318-2.48 0-4.416 1.8-4.416 4.262 0 3.15 2.647 3.755 4.082 4.177 1.059.324 3.51.942 3.51 3.39 0 1.856-1.504 3.15-3.162 3.15-1.936 0-3.19-1.294-3.274-3.277H36.43v.028zm-17.623 4.43h8.067V37.37h-6.492V22.94h-1.575v15.864zM7.607 24.74l3.023 7.285H4.528l3.078-7.285zM0 38.804h1.644l2.285-5.33h7.3l2.27 5.33h1.728L8.47 22.94H6.715L0 38.804z",
    clipRule: "evenodd"
  }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
    fill: "#793D58",
    d: "M125.493 10.127l.502-.507 5.865 5.921h8.289v8.355L146 29.817l-5.851 5.921v8.355h-8.289L125.995 50l-5.851-5.907h-8.29v-8.369l-5.851-5.92 5.851-5.922v-8.355h8.29l5.349-5.4zm-5.057 6.85h-7.147v7.51l-5.266 5.316 5.266 5.317v7.51h7.44l5.266 5.316 5.266-5.316h7.453v-7.51l5.266-5.317-5.266-5.316v-7.51h-7.453l-5.266-5.317-5.266 5.316h-.293zm8.429 8.916s.097-4.065-1.045-5.007c-1.157-.956-3.748-1.013-3.971 1.688-.181 2.405 2.661 3.249 3.664 3.797 1.003.535 4.542 2.307 5.406 5.246.863 2.94-1.519 6.428-3.623 7.216-2.103.801-5.893 2.095-9.32-1.168-2.744-2.63-1.435-8.593 2.787-8.818 2.424-.127 4.513.76 4.472 3.192-.056 2.518-3.191 2.054-3.274 2.026-.028-.38-.028-.605-.028-.605s1.853-.422 1.727-1.744c-.097-1.21-.766-2.293-2.814-2.096-2.034.197-3.497 2.672-2.702 5.457.78 2.715 4.137 4.43 7.94 3.137 0 0 3.163-1.224 3.107-4.276-.056-3.066-3.441-4.36-5.168-5.429-1.728-1.069-3.859-2.335-3.748-4.81.111-2.49 1.755-4.346 3.943-4.304 2.201.028 2.521.69 2.521.69l.126-.31h.794v6.132h-.794v-.014z"
  }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
    fill: "#fff",
    d: "M128.864 25.893s.098-4.065-1.044-5.007c-1.157-.956-3.748-1.013-3.971 1.688-.181 2.405 2.661 3.249 3.664 3.797 1.003.535 4.542 2.307 5.405 5.247.864 2.939-1.518 6.427-3.622 7.215-2.103.801-5.893 2.095-9.32-1.168-2.744-2.63-1.435-8.593 2.787-8.818 2.424-.127 4.513.76 4.472 3.192-.056 2.518-3.191 2.054-3.274 2.026-.028-.38-.028-.605-.028-.605s1.853-.422 1.727-1.744c-.097-1.21-.766-2.293-2.814-2.096-2.034.197-3.497 2.673-2.702 5.457.78 2.715 4.137 4.43 7.94 3.137 0 0 3.163-1.224 3.107-4.276-.056-3.066-3.441-4.36-5.168-5.429-1.728-1.069-3.859-2.335-3.748-4.81.111-2.49 1.755-4.346 3.943-4.304 2.201.028 2.521.69 2.521.69l.125-.31h.795v6.132h-.795v-.014z"
  }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
    fill: "#C4A47E",
    fillRule: "evenodd",
    d: "M125.493 10.127l-5.349 5.4h-8.29v8.369l-5.851 5.907 5.851 5.921v8.355h8.29l5.851 5.907 5.865-5.907h8.289v-8.355l5.851-5.92-5.851-5.908v-8.369h-8.289l-5.865-5.92-.502.52zm-5.057 6.85h.293l5.266-5.317 5.266 5.316h7.453v7.51l5.266 5.317-5.266 5.317v7.524h-7.453l-5.266 5.317-5.266-5.317h-7.44V35.12l-5.266-5.317 5.266-5.316v-7.51h7.147z",
    clipRule: "evenodd"
  }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
    fill: "#fff",
    d: "M95.903 15.471h-1.532V0h1.532v15.471zm-43.117 2.462a.824.824 0 01.418-.45.526.526 0 01.264-.057c.474 0 .766.422.766.858a.905.905 0 01-.055.338c-.112.295-.376.506-.697.506-.446 0-.752-.422-.752-.844 0-.127.028-.239.056-.351zm-1.324 1.153c-.306-.14-.474-.464-.474-.788 0-.436.28-.858.753-.858.111 0 .195.014.278.056.32.141.488.45.488.802 0 .422-.306.844-.766.844a.582.582 0 01-.279-.056zm7.3-14.402c-.153-.155-.237-.352-.237-.633 0-.127.014-.24.07-.338a.77.77 0 01.71-.506c.32 0 .572.21.683.506a.954.954 0 01.056.338c0 .14-.028.253-.056.351-.111.296-.362.507-.682.507-.237.014-.404-.057-.544-.225zM61.743 8.1c.418.45.6.957.6 1.533l.013 4.501s2.745.113 3.051-.127c.349-.295.432-.436.432-.9v-5.64h1.533v5.626c0 .872.39 1.041 1.31 1.041.919 0 1.28-.155 1.28-1.013V7.468h1.547v5.626c0 .872.39 1.041 1.31 1.041s1.281-.183 1.281-1.04V7.467h1.533v5.654c0 .464.181.83.64 1.027.266.211 14.684.028 14.712 0 .432-.21.432-.563.432-1.027V0h1.546v13.32c0 .576-.194 1.068-.612 1.504-.418.422-.892.633-1.477.647H77.04c-.808-.014-1.282-.366-1.811-.858-.53.492-.92.858-1.714.858h-.71c-.571 0-1.059-.21-1.49-.647-.265-.267-.419-.647-.6-.97-.515.886-.877 1.617-2.117 1.617h-.739c-.808 0-1.17-.351-1.7-.872-.529.52-.919.872-1.713.872H54.332c-.808-.014-1.184-.366-1.741-.872-.293.296-.544.577-.934.732-.237.098-.473.14-.766.14H48.119v1.604c0 .59-.21 1.097-.627 1.518-.432.436-.92.633-1.49.633h-1.074v-.787h.349c.92 0 1.281-.718 1.281-1.59V7.47h1.533l.014 6.68s2.675.127 2.953-.098c.334-.296.362-.465.362-.915V7.468h1.547v5.668c0 1.126.599 1.013 1.672 1.013h1.95l-.014-4.515c0-.562.195-1.055.627-1.533.432-.436.92-.633 1.49-.633h1.533c.306 0 .571.057.808.155.265.113.488.267.71.478zm-2.27.155c-.948 0-1.338.703-1.338 1.603v4.276h2.675V9.859c0-.9-.404-1.603-1.337-1.603z"
  })]
});

const offerIcon = /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("svg", {
  xmlns: "http://www.w3.org/2000/svg",
  width: "27",
  height: "27",
  fill: "none",
  viewBox: "0 0 27 27",
  children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
    stroke: "#BEA782",
    strokeMiterlimit: "10",
    d: "M23.8.7l-8.9 1.1L1 15.7l10 10 13.9-13.9L26 2.9 23.8.7z"
  }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
    stroke: "#BEA782",
    strokeMiterlimit: "10",
    d: "M20.4 7.8a1.5 1.5 0 100-3 1.5 1.5 0 000 3z"
  })]
});

const stayIcon = /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("svg", {
  xmlns: "http://www.w3.org/2000/svg",
  width: "28",
  height: "19",
  fill: "none",
  viewBox: "0 0 28 19",
  children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
    fill: "#BEA782",
    d: "M27.3 5.5c-.3 0-.5.2-.5.5v1.9H7.6c.3-.3.4-.7.4-1.1 0-1.2-1.4-2.1-3.1-2.1-1.8 0-3.1.9-3.1 2.1 0 .4.2.7.4 1.1H1V1.4C1 1.1.8.9.5.9s-.5.2-.5.5V18.2c0 .3.2.5.5.5s.5-.2.5-.5v-4.8h25.7v4.8c0 .3.2.5.5.5s.5-.2.5-.5V6c.1-.3-.1-.5-.4-.5zM2.8 6.9c0-.5.9-1.1 2.1-1.1 1.2 0 2.1.6 2.1 1.1C7 7.4 6.1 8 4.9 8c-1.2-.1-2.1-.6-2.1-1.1zM1 12.2V9h25.7v3.2H1z"
  })
});

const dineIcon = /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("svg", {
  xmlns: "http://www.w3.org/2000/svg",
  width: "29",
  height: "20",
  fill: "none",
  viewBox: "0 0 29 20",
  children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
    fill: "#BEA782",
    d: "M14.5 3c-4.3 0-7.8 3.5-7.8 7.8s3.5 7.8 7.8 7.8 7.8-3.5 7.8-7.8S18.8 3 14.5 3zm0 14.7c-3.8 0-6.9-3.1-6.9-6.9 0-3.8 3.1-6.9 6.9-6.9 3.8 0 6.9 3.1 6.9 6.9-.1 3.8-3.1 6.9-6.9 6.9zM28 .1c-.1-.1-.3-.1-.5 0-.1.1-3.4 2.2-3.4 9.4 0 .3.2.5.5.5h2.7v8.6c0 .3.2.5.5.5s.5-.2.5-.5V.5c-.1-.2-.1-.3-.3-.4zm-2.9 9c.1-3.2.8-5.2 1.5-6.4.3-.5.5-.8.8-1.1v7.5h-2.3zM5.3 0c-.3 0-.5.2-.5.5v5.7c0 .1-.1.2-.2.2H3.5V.5C3.5.2 3.3 0 3 0s-.5.2-.5.5v5.9H1.4c-.1 0-.2-.1-.2-.2V.5C1.2.2 1 0 .7 0S.2.2.2.5v5.7c0 .6.5 1.1 1.1 1.1h1.1v11.3c0 .3.2.5.5.5s.5-.2.5-.5V7.3h1.1c.6 0 1.1-.5 1.1-1.1V.5c.1-.3-.1-.5-.3-.5z"
  })
});

const entertainmentIcon = /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("svg", {
  xmlns: "http://www.w3.org/2000/svg",
  width: "28",
  height: "30",
  fill: "none",
  viewBox: "0 0 28 30",
  children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
    stroke: "#BEA782",
    strokeMiterlimit: "10",
    d: "M9.3 6.9l16.9-5.4v18.2M9.3 6.9l16.9-5.4M9.3 11.9l16.9-5.5"
  }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
    stroke: "#BEA782",
    strokeMiterlimit: "10",
    d: "M22.806 23.133c2.194-.56 3.696-2.099 3.354-3.436-.341-1.338-2.396-1.969-4.59-1.409s-3.696 2.099-3.355 3.436c.342 1.338 2.397 1.969 4.591 1.409zM9.3 6.9V25M9.3 25c.3 1.4-1.2 2.9-3.4 3.5-2.2.6-4.3-.1-4.6-1.4-.3-1.4 1.2-2.9 3.4-3.5 2.2-.6 4.2 0 4.6 1.4z"
  })]
});

const meetnEventIcon = /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("svg", {
  xmlns: "http://www.w3.org/2000/svg",
  width: "33",
  height: "21",
  fill: "none",
  viewBox: "0 0 33 21",
  children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
    stroke: "#BEA782",
    strokeMiterlimit: "10",
    d: "M21.7 6.4c0 3.9-2.8 7.1-5.2 7.1-2 0-5.2-3.2-5.2-7.1 0-3.9 2.3-5.9 5.2-5.9 2.8.1 5.2 2 5.2 5.9z"
  }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
    stroke: "#BEA782",
    strokeMiterlimit: "10",
    d: "M19.5 13.2c-1.4 1.9-3 3-3 3s-1.6-1.2-3-3c-3.3 1.6-5.7 5.3-5.7 5.3s3.9 1.6 8.6 1.6c4.8 0 8.6-1.6 8.6-1.6s-2.2-3.7-5.5-5.3zM29.4 7.9c0 2.4-1.7 4.4-3.2 4.4-1.2 0-3.2-1.9-3.2-4.4 0-2.4 1.4-3.6 3.2-3.6 1.8 0 3.2 1.2 3.2 3.6z"
  }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
    stroke: "#BEA782",
    strokeMiterlimit: "10",
    d: "M22.3 13.6c.6-.6 1.3-1.2 2.1-1.6.8 1.1 1.8 1.9 1.8 1.9s1-.7 1.8-1.9c2 1 3.5 3.2 3.5 3.2s-2.4 1-5.3 1c-.6 0-1.1 0-1.7-.1 0 .1-1.3-1.5-2.2-2.5zM3.6 7.9c0 2.4 1.7 4.4 3.2 4.4 1.2 0 3.2-1.9 3.2-4.4 0-2.4-1.4-3.6-3.2-3.6-1.8 0-3.2 1.2-3.2 3.6z"
  }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
    stroke: "#BEA782",
    strokeMiterlimit: "10",
    d: "M10.7 13.6c-.6-.6-1.3-1.2-2.1-1.6-.8 1.1-1.8 1.9-1.8 1.9s-1-.7-1.8-1.9c-2 1-3.5 3.2-3.5 3.2s2.4 1 5.3 1c.6 0 1.1 0 1.7-.1-.1.1 1.3-1.5 2.2-2.5z"
  })]
});

const healthnWellnessIcon = /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("svg", {
  xmlns: "http://www.w3.org/2000/svg",
  width: "32",
  height: "31",
  fill: "none",
  viewBox: "0 0 32 31",
  children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
    stroke: "#BEA782",
    strokeMiterlimit: "10",
    strokeWidth: "0.938",
    d: "M14.8 29.8c-9.8 1-21.7-10.3-6.4-28 2.4 6.1 15.5 13.6 8.2 26.4-3.3-2.9-7.6-9.8-7.5-16.1-2 7.7 2.1 13.8 5.7 17.7z"
  }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
    stroke: "#BEA782",
    strokeMiterlimit: "10",
    strokeWidth: "0.938",
    d: "M18.9 27.9c7.4-.1 15.4-7.7 10.8-25.5-3.8 1.5-10.3 4.5-13.2 8.3 2.4 2.7 3.2 6.3 3.2 6.3 1.7-3.6 4.7-6.7 4.7-6.7-2.2 4-4.1 9.7-4.1 9.7.7 5.3-1.4 7.9-1.4 7.9z"
  })]
});

const photoGallery = /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("svg", {
  xmlns: "http://www.w3.org/2000/svg",
  width: "30",
  height: "24",
  fill: "none",
  viewBox: "0 0 30 24",
  children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
    stroke: "#BEA782",
    strokeMiterlimit: "10",
    strokeWidth: "0.933",
    d: "M14.7 21.1a7.9 7.9 0 100-15.8 7.9 7.9 0 000 15.8z"
  }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
    stroke: "#BEA782",
    strokeMiterlimit: "10",
    strokeWidth: "0.933",
    d: "M14.7 18.1a4.9 4.9 0 100-9.8 4.9 4.9 0 000 9.8zM24.7 9.7a1.5 1.5 0 100-3 1.5 1.5 0 000 3z"
  }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
    stroke: "#BEA782",
    strokeMiterlimit: "10",
    strokeWidth: "0.933",
    d: "M17.4 10.5c1 1 1 2.8.8 3-.2.2-.5-1.2-1.6-2.2-1-1-2.4-1.3-2.2-1.6.2-.1 1.9-.2 3 .8z"
  }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
    stroke: "#BEA782",
    strokeMiterlimit: "10",
    strokeWidth: "0.933",
    d: "M26.9 5h-.6v-.3c0-.5-.4-.8-.8-.8H24c-.5 0-.8.4-.8.8V5h-.4c-1.2 0-2.2-.9-2.2-2.1 0-1.2-.9-2.2-2.1-2.2H11c-1.2 0-2.2.9-2.2 2.1C8.8 4 7.9 5 6.7 5H2.6c-1 0-1.8.8-1.8 1.8v14.7c0 1 .8 1.8 1.8 1.8H27c1 0 1.8-.8 1.8-1.8V6.8c-.1-1-.9-1.8-1.9-1.8z"
  })]
});

const alsafirRings = /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("svg", {
  xmlns: "http://www.w3.org/2000/svg",
  width: "51",
  height: "51",
  fill: "none",
  viewBox: "0 0 51 51",
  children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
    stroke: "#9E8E71",
    strokeLinecap: "round",
    strokeLinejoin: "bevel",
    strokeMiterlimit: "10",
    strokeWidth: "0.725",
    d: "M35.7 44.4C32.6 46 29.1 47 25.4 47 13.5 47 3.9 37.3 3.9 25.4c0-11.9 9.6-21.5 21.5-21.5S47 13.5 47 25.4c0 4.5-1.4 8.7-3.7 12.1-.5.8-1.1 1.5-1.7 2.2"
  }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
    stroke: "#9E8E71",
    strokeLinecap: "round",
    strokeLinejoin: "bevel",
    strokeMiterlimit: "10",
    strokeWidth: "0.84",
    d: "M13.5 3.4c3.5-1.9 7.6-3 11.9-3 13.8 0 25 11.2 25 25s-11.2 25-25 25-25-11.2-25-25c0-5.2 1.6-10 4.3-14 .6-.9 1.3-1.8 2-2.6"
  })]
});

const blogIcon = /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("svg", {
  xmlns: "http://www.w3.org/2000/svg",
  width: "24",
  height: "22",
  fill: "none",
  viewBox: "0 0 24 22",
  children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
    stroke: "#BEA782",
    strokeMiterlimit: "10",
    d: "M9.5 17.5h4.2c2.7-1.6 4.4-4.5 4.4-7.8h-13c0 3.4 1.7 6.3 4.4 7.8zM2 18.5c2.1 1.2 4.4 2.1 6.8 2.4h5.6c2.4-.4 4.6-1.2 6.8-2.4H2zM9.3 3.1c0 1.4 1.5 1.4 1.5 2.8S9.3 7.3 9.3 8.7M12.9.4c0 1.4-1.5 1.4-1.5 2.8s1.5 1.4 1.5 2.8-1.5 1.4-1.5 2.8M14.1 4.5c.4.3.8.7.8 1.4 0 1.4-1.5 1.4-1.5 2.8"
  }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
    stroke: "#BEA782",
    strokeMiterlimit: "10",
    d: "M17.9 11.8s1.3-2.2 3.1-1c1.6 1.1-.2 4.3-4.8 4.7"
  })]
});

const brandStoryIcon = /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("svg", {
  xmlns: "http://www.w3.org/2000/svg",
  width: "22",
  height: "19",
  fill: "none",
  viewBox: "0 0 22 19",
  children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
    stroke: "#BEA782",
    strokeMiterlimit: "10",
    d: "M20.1 5.1h-18V18h18V5.1z"
  }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
    stroke: "#BEA782",
    strokeMiterlimit: "10",
    d: "M19.736 1.282L1.854 3.338l.205 1.788L19.942 3.07l-.206-1.788z"
  }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
    stroke: "#BEA782",
    strokeMiterlimit: "10",
    d: "M3.5 5l-1.4.1 1.6-2L5 3 3.5 5zM5.9 4.7l-1.3.1 1.5-1.9 1.4-.2-1.6 2zM8.4 4.4L7 4.6l1.6-2 1.3-.2-1.5 2zM10.8 4.1l-1.3.2 1.5-2 1.4-.2-1.6 2zM13.3 3.8l-1.4.2 1.6-2 1.3-.1-1.5 1.9zM15.8 3.6l-1.4.1 1.5-2 1.4-.1-1.5 2zM18.2 3.3l-1.3.1 1.5-1.9 1.4-.2-1.6 2zM20.1 16.1h-18v1.8h18v-1.8z"
  }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
    stroke: "#BEA782",
    strokeMiterlimit: "10",
    d: "M3.5 17.9H2.1l1.8-1.8h1.4l-1.8 1.8zM6 17.9H4.6l1.8-1.8h1.3L6 17.9zM8.4 17.9H7.1l1.7-1.8h1.4l-1.8 1.8zM10.9 17.9H9.5l1.8-1.8h1.4l-1.8 1.8zM13.4 17.9H12l1.8-1.8h1.3l-1.7 1.8zM15.8 17.9h-1.3l1.7-1.8h1.4l-1.8 1.8zM18.3 17.9h-1.4l1.8-1.8h1.4l-1.8 1.8zM8.8 8l4.6 2.6-4.6 2.7V8z"
  })]
});

const arrowIcon = /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("svg", {
  xmlns: "http://www.w3.org/2000/svg",
  width: "30",
  height: "51",
  fill: "none",
  viewBox: "0 0 30 51",
  children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("g", {
    clipPath: "url(#clip0)",
    children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
      stroke: "#CAB493",
      strokeMiterlimit: "10",
      d: "M.429.491l28.575 24.773L.429 50.035"
    })
  }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("defs", {
    children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("clipPath", {
      id: "clip0",
      children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
        fill: "#fff",
        d: "M0 0H30V50.526H0z"
      })
    })
  })]
});

const downIcon = /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("svg", {
  xmlns: "http://www.w3.org/2000/svg",
  width: "14",
  height: "8",
  fill: "none",
  viewBox: "0 0 14 8",
  children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
    fill: "#BEA782",
    d: "M1.645 0L7 4.949 12.355 0 14 1.531 7 8 0 1.531 1.645 0z"
  })
});

const addressIcon = /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("svg", {
  xmlns: "http://www.w3.org/2000/svg",
  x: "0",
  y: "0",
  baseProfile: "tiny",
  overflow: "visible",
  version: "1.2",
  viewBox: "0 0 100 100",
  xmlSpace: "preserve",
  children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
    fill: "none",
    stroke: "#9E8E71",
    strokeLinecap: "round",
    strokeLinejoin: "bevel",
    strokeMiterlimit: "10",
    d: "M69.8 86.8c-5.9 3.2-12.7 5-19.9 5C26.8 91.8 8.1 73.1 8.1 50S26.8 8.3 49.9 8.3 91.6 27 91.6 50.1c0 8.7-2.7 16.8-7.2 23.5-1 1.5-2.2 3-3.4 4.3"
  }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
    fill: "none",
    stroke: "#9E8E71",
    strokeLinecap: "round",
    strokeLinejoin: "bevel",
    strokeMiterlimit: "10",
    d: "M26.8 7.5c6.9-3.7 14.7-5.8 23.1-5.8 26.8 0 48.4 21.7 48.4 48.4 0 26.8-21.7 48.4-48.4 48.4S1.4 76.8 1.4 50.1c0-10.1 3.1-19.4 8.4-27.2 1.2-1.8 2.5-3.4 3.9-5"
  }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("g", {
    children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
      fill: "#BEA782",
      d: "M50.9 14.6c10.4 0 20.1 8.6 21.4 19.8.5 4.4-.3 8.5-1.5 12.7-1.8 6.7-4.6 12.9-7.8 19-3.1 6-6.4 11.8-10.1 17.4-1.6 2.5-4.3 2.5-5.9 0-6.1-9.6-11.7-19.4-15.8-30-1.7-4.4-3-9-3.6-13.7-1.2-9.8 4.6-19.7 13.7-23.4 2.8-1.1 5.7-1.7 9.6-1.8zm-.8 12.9c-5.4 0-9.7 4.3-9.7 9.7 0 5.3 4.3 9.6 9.6 9.6s9.6-4.4 9.6-9.6c.1-5.4-4.3-9.7-9.5-9.7z"
    })
  })]
});

const callIcon = /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("svg", {
  xmlns: "http://www.w3.org/2000/svg",
  x: "0",
  y: "0",
  baseProfile: "tiny",
  overflow: "visible",
  version: "1.2",
  viewBox: "0 0 100 100",
  xmlSpace: "preserve",
  children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
    fill: "none",
    stroke: "#9E8E71",
    strokeLinecap: "round",
    strokeLinejoin: "bevel",
    strokeMiterlimit: "10",
    d: "M69.8 86.8c-5.9 3.2-12.7 5-19.9 5C26.8 91.8 8.1 73.1 8.1 50S26.8 8.3 49.9 8.3 91.6 27 91.6 50.1c0 8.7-2.7 16.8-7.2 23.5-1 1.5-2.2 3-3.4 4.3"
  }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
    fill: "none",
    stroke: "#9E8E71",
    strokeLinecap: "round",
    strokeLinejoin: "bevel",
    strokeMiterlimit: "10",
    d: "M26.8 7.5c6.9-3.7 14.7-5.8 23.1-5.8 26.8 0 48.4 21.7 48.4 48.4 0 26.8-21.7 48.4-48.4 48.4S1.4 76.8 1.4 50.1c0-10.1 3.1-19.4 8.4-27.2 1.2-1.8 2.5-3.4 3.9-5"
  }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("g", {
    children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
      fill: "#BEA782",
      fillRule: "evenodd",
      d: "M76.7 61.5c-1.5-.7-8.7-4.2-10-4.7-1.3-.5-2.3-.7-3.3.7-1 1.5-3.8 4.7-4.6 5.7-.9 1-1.7 1.1-3.2.4-1.5-.7-6.2-2.2-11.8-7.2-4.3-3.8-7.3-8.6-8.1-10-.8-1.5-.1-2.2.6-3 .7-.7 1.5-1.7 2.2-2.5.2-.3.4-.5.5-.7.3-.5.6-1 .9-1.7.5-1 .3-1.8-.1-2.5s-3.3-7.9-4.5-10.8c-1.2-2.9-2.4-2.4-3.3-2.4-.8 0-1.8-.1-2.8-.1-1 0-2.6.4-3.9 1.8-1.3 1.5-5.1 5-5.1 12.1 0 1.7.3 3.4.8 4.9 1.5 5.1 4.7 9.3 5.2 10.1.7.9 10.1 16.1 25 21.9 14.9 5.8 14.9 3.9 17.6 3.6 2.7-.2 8.7-3.5 9.9-6.9 1.2-3.4 1.2-6.3.9-6.9-.4-.7-1.4-1.1-2.9-1.8z"
    })
  })]
});

const emailIcon = /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("svg", {
  xmlns: "http://www.w3.org/2000/svg",
  x: "0",
  y: "0",
  baseProfile: "tiny",
  overflow: "visible",
  version: "1.2",
  viewBox: "0 0 100 100",
  xmlSpace: "preserve",
  children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
    fill: "none",
    stroke: "#9E8E71",
    strokeLinecap: "round",
    strokeLinejoin: "bevel",
    strokeMiterlimit: "10",
    d: "M69.8 86.8c-5.9 3.2-12.7 5-19.9 5C26.8 91.8 8.1 73.1 8.1 50S26.8 8.3 49.9 8.3 91.6 27 91.6 50.1c0 8.7-2.7 16.8-7.2 23.5-1 1.5-2.2 3-3.4 4.3"
  }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
    fill: "none",
    stroke: "#9E8E71",
    strokeLinecap: "round",
    strokeLinejoin: "bevel",
    strokeMiterlimit: "10",
    d: "M26.8 7.5c6.9-3.7 14.7-5.8 23.1-5.8 26.8 0 48.4 21.7 48.4 48.4 0 26.8-21.7 48.4-48.4 48.4S1.4 76.8 1.4 50.1c0-10.1 3.1-19.4 8.4-27.2 1.2-1.8 2.5-3.4 3.9-5"
  }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("g", {
    fill: "#BEA782",
    children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
      d: "M82.5 67.9c-.2.6-.4 1.1-.5 1.6-6.6-6.5-13.1-13-19.6-19.5 6.6-6.5 13.1-13 19.7-19.5.1.4.3 1 .5 1.5-.1 12-.1 24-.1 35.9zM79.2 27.7l-2.8 2.8C68.2 38.7 60 46.9 51.8 55.2c-1.1 1.2-2.4 1.2-3.5 0-9-9-18-18-26.9-27l-.5-.5c.8-.2 1.4-.3 2-.4H76.5c.8-.2 1.7-.1 2.7.4z"
    }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
      d: "M59.5 52.8c6.5 6.5 13.1 12.9 19.7 19.5-.8.2-1.4.3-2.1.5H23.6c-.9 0-1.8-.1-2.7-.5 6.6-6.5 13.1-13 19.6-19.4 1.6 1.6 3.4 3.4 5.2 5.1 1.9 1.9 4.6 2.4 6.9 1.2.7-.3 1.3-.8 1.8-1.3 1.6-1.5 3.1-3.1 4.7-4.7.2-.1.3-.3.4-.4zM18.1 30.5c6.5 6.5 13.1 13 19.6 19.4-6.6 6.5-13.1 13-19.7 19.5-.4-.7-.5-1.5-.5-2.5v-18-16c0-.8.2-1.6.6-2.4z"
    })]
  })]
});

const mailIcon = /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("svg", {
  xmlns: "http://www.w3.org/2000/svg",
  x: "0",
  y: "0",
  baseProfile: "tiny",
  overflow: "visible",
  version: "1.2",
  viewBox: "0 0 100 100",
  xmlSpace: "preserve",
  children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
    fill: "none",
    stroke: "#9E8E71",
    strokeLinecap: "round",
    strokeLinejoin: "bevel",
    strokeMiterlimit: "10",
    d: "M69.8 86.8c-5.9 3.2-12.7 5-19.9 5C26.8 91.8 8.1 73.1 8.1 50S26.8 8.3 49.9 8.3 91.6 27 91.6 50.1c0 8.7-2.7 16.8-7.2 23.5-1 1.5-2.2 3-3.4 4.3"
  }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
    fill: "none",
    stroke: "#9E8E71",
    strokeLinecap: "round",
    strokeLinejoin: "bevel",
    strokeMiterlimit: "10",
    d: "M26.8 7.5c6.9-3.7 14.7-5.8 23.1-5.8 26.8 0 48.4 21.7 48.4 48.4 0 26.8-21.7 48.4-48.4 48.4S1.4 76.8 1.4 50.1c0-10.1 3.1-19.4 8.4-27.2 1.2-1.8 2.5-3.4 3.9-5"
  }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
    fill: "#BEA782",
    d: "M41.8 82.5h13.1V49.7H64l1-11H54.9v-6.2c0-2.6.5-3.6 3-3.6H65V17.5h-9.1c-9.7 0-14.1 4.3-14.1 12.5v8.7H35v11.1h6.8v32.7z"
  })]
});

const faxIcon = /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("svg", {
  xmlns: "http://www.w3.org/2000/svg",
  x: "0",
  y: "0",
  baseProfile: "tiny",
  overflow: "visible",
  version: "1.2",
  viewBox: "0 0 100 100",
  xmlSpace: "preserve",
  children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
    fill: "none",
    stroke: "#9E8E71",
    strokeLinecap: "round",
    strokeLinejoin: "bevel",
    strokeMiterlimit: "10",
    d: "M69.8 86.8c-5.9 3.2-12.7 5-19.9 5C26.8 91.8 8.1 73.1 8.1 50S26.8 8.3 49.9 8.3 91.6 27 91.6 50.1c0 8.7-2.7 16.8-7.2 23.5-1 1.5-2.2 3-3.4 4.3"
  }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
    fill: "none",
    stroke: "#9E8E71",
    strokeLinecap: "round",
    strokeLinejoin: "bevel",
    strokeMiterlimit: "10",
    d: "M26.8 7.5c6.9-3.7 14.7-5.8 23.1-5.8 26.8 0 48.4 21.7 48.4 48.4 0 26.8-21.7 48.4-48.4 48.4S1.4 76.8 1.4 50.1c0-10.1 3.1-19.4 8.4-27.2 1.2-1.8 2.5-3.4 3.9-5"
  }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("g", {
    fill: "#BEA782",
    children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
      d: "M67.5 70v-.9-13.7c0-1.9-1-2.9-2.9-2.9H35.3c-1.8 0-2.8 1-2.8 2.9V70c-.2 0-.4.1-.6.1h-6.8c-4.3 0-7.6-3.3-7.6-7.6V42.7c0-4.3 3.3-7.6 7.6-7.6h49.7c4.4 0 7.6 3.3 7.6 7.6v19.8c0 4.3-3.3 7.6-7.6 7.6-2.3-.1-4.8-.1-7.3-.1zM70 42.5c-1.4 0-2.5 1.1-2.5 2.6 0 1.3 1.1 2.4 2.4 2.4 1.4 0 2.6-1.1 2.5-2.5.1-1.4-1-2.5-2.4-2.5zM67.5 32.5h-35v-3.4-6.3c0-1.6 1-2.7 2.7-2.7h29.6c1.7 0 2.7 1 2.7 2.7V32.5z"
    }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
      d: "M37.5 57.5h25V77c0 1.9-1 2.9-2.9 2.9H40.3c-1.9 0-2.8-1-2.8-2.8V57.5zm12.4 10h4.8c1.6 0 2.7-1 2.7-2.5 0-1.4-1.1-2.5-2.7-2.5h-9.6c-1.6 0-2.7 1.1-2.7 2.5s1.1 2.5 2.7 2.5h4.8zM50 70h-4.8c-1.5 0-2.6 1.1-2.7 2.5 0 1.4 1.1 2.5 2.6 2.5h9.8c1.5 0 2.6-1.1 2.6-2.5S56.4 70 54.8 70H50z"
    })]
  })]
});

const instagramIcon = /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("svg", {
  xmlns: "http://www.w3.org/2000/svg",
  x: "0",
  y: "0",
  baseProfile: "tiny",
  overflow: "visible",
  version: "1.2",
  viewBox: "0 0 100 100",
  xmlSpace: "preserve",
  children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
    fill: "none",
    stroke: "#9E8E71",
    strokeLinecap: "round",
    strokeLinejoin: "bevel",
    strokeMiterlimit: "10",
    d: "M69.8 86.8c-5.9 3.2-12.7 5-19.9 5C26.8 91.8 8.1 73.1 8.1 50S26.8 8.3 49.9 8.3 91.6 27 91.6 50.1c0 8.7-2.7 16.8-7.2 23.5-1 1.5-2.2 3-3.4 4.3"
  }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
    fill: "none",
    stroke: "#9E8E71",
    strokeLinecap: "round",
    strokeLinejoin: "bevel",
    strokeMiterlimit: "10",
    d: "M26.8 7.5c6.9-3.7 14.7-5.8 23.1-5.8 26.8 0 48.4 21.7 48.4 48.4 0 26.8-21.7 48.4-48.4 48.4S1.4 76.8 1.4 50.1c0-10.1 3.1-19.4 8.4-27.2 1.2-1.8 2.5-3.4 3.9-5"
  }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("g", {
    fill: "#BEA782",
    children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
      d: "M50 27.5c7.3 0 8.2 0 11.1.2 2.7.1 4.1.6 5.1.9 1.3.5 2.2 1.1 3.2 2.1s1.6 1.9 2.1 3.2c.4 1 .8 2.4.9 5.1.1 2.9.2 3.8.2 11.1s0 8.2-.2 11.1c-.1 2.7-.6 4.1-.9 5.1-.5 1.3-1.1 2.2-2.1 3.2s-1.9 1.6-3.2 2.1c-1 .4-2.4.8-5.1.9-2.9.1-3.8.2-11.1.2s-8.2 0-11.1-.2c-2.7-.1-4.1-.6-5.1-.9-1.3-.5-2.2-1.1-3.2-2.1s-1.6-1.9-2.1-3.2c-.4-1-.8-2.4-.9-5.1-.1-2.9-.2-3.8-.2-11.1s0-8.2.2-11.1c.1-2.7.6-4.1.9-5.1.5-1.3 1.1-2.2 2.1-3.2s1.9-1.6 3.2-2.1c1-.4 2.4-.8 5.1-.9 2.9-.2 3.8-.2 11.1-.2m0-5c-7.5 0-8.4 0-11.3.2-2.9.1-4.9.6-6.7 1.3-1.8.7-3.3 1.6-4.9 3.2-1.5 1.5-2.5 3.1-3.2 4.9-.7 1.7-1.1 3.7-1.3 6.7-.1 2.9-.2 3.9-.2 11.3s0 8.4.2 11.3c.1 2.9.6 4.9 1.3 6.7.7 1.8 1.6 3.3 3.2 4.9 1.5 1.5 3.1 2.5 4.9 3.2 1.7.7 3.7 1.1 6.7 1.3 2.9.1 3.9.2 11.3.2 7.5 0 8.4 0 11.3-.2 2.9-.1 4.9-.6 6.7-1.3 1.8-.7 3.3-1.6 4.9-3.2 1.5-1.5 2.5-3.1 3.2-4.9.7-1.7 1.1-3.7 1.3-6.7.1-2.9.2-3.9.2-11.3s0-8.4-.2-11.3c-.1-2.9-.6-4.9-1.3-6.7-.7-1.8-1.6-3.3-3.2-4.9-1.5-1.5-3.1-2.5-4.9-3.2-1.7-.7-3.7-1.1-6.7-1.3-2.9-.2-3.8-.2-11.3-.2"
    }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
      d: "M50 35.9c-7.8 0-14.1 6.3-14.1 14.1S42.2 64.1 50 64.1 64.1 57.8 64.1 50 57.8 35.9 50 35.9m0 23.3c-5.1 0-9.2-4.1-9.2-9.2s4.1-9.2 9.2-9.2 9.2 4.1 9.2 9.2-4.1 9.2-9.2 9.2"
    }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
      d: "M68 35.3c0 1.8-1.5 3.3-3.3 3.3-1.8 0-3.3-1.5-3.3-3.3 0-1.8 1.5-3.3 3.3-3.3 1.8 0 3.3 1.5 3.3 3.3"
    })]
  })]
});

const whatsappIcon = /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("svg", {
  xmlns: "http://www.w3.org/2000/svg",
  x: "0",
  y: "0",
  baseProfile: "tiny",
  overflow: "visible",
  version: "1.2",
  viewBox: "0 0 100 100",
  xmlSpace: "preserve",
  children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
    fill: "none",
    stroke: "#9E8E71",
    strokeLinecap: "round",
    strokeLinejoin: "bevel",
    strokeMiterlimit: "10",
    d: "M69.8 86.8c-5.9 3.2-12.7 5-19.9 5C26.8 91.8 8.1 73.1 8.1 50S26.8 8.3 49.9 8.3 91.6 27 91.6 50.1c0 8.7-2.7 16.8-7.2 23.5-1 1.5-2.2 3-3.4 4.3"
  }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
    fill: "none",
    stroke: "#9E8E71",
    strokeLinecap: "round",
    strokeLinejoin: "bevel",
    strokeMiterlimit: "10",
    d: "M26.8 7.5c6.9-3.7 14.7-5.8 23.1-5.8 26.8 0 48.4 21.7 48.4 48.4 0 26.8-21.7 48.4-48.4 48.4S1.4 76.8 1.4 50.1c0-10.1 3.1-19.4 8.4-27.2 1.2-1.8 2.5-3.4 3.9-5"
  }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("g", {
    fill: "#BEA782",
    fillRule: "evenodd",
    children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
      d: "M75 48.7C74.6 35.6 63.8 25 50.5 25 37.3 25 26.6 35.3 26 48.3v1.1c0 4.6 1.3 8.9 3.5 12.6L25 75l13.6-4.3c3.5 1.9 7.6 3 11.9 3C64 73.7 75 62.8 75 49.4v-.7zM50.5 69.8c-4.2 0-8.1-1.2-11.4-3.4L31.2 69l2.6-7.6c-2.5-3.4-3.9-7.5-3.9-12 0-.7 0-1.3.1-2 1-10.4 9.8-18.5 20.5-18.5 10.8 0 19.7 8.3 20.6 18.9 0 .5.1 1.1.1 1.6-.1 11.3-9.4 20.4-20.7 20.4z"
    }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
      d: "M61.7 54.3c-.6-.3-3.6-1.7-4.1-1.9-.6-.2-1-.3-1.4.3-.4.6-1.6 1.9-1.9 2.3-.4.4-.7.4-1.3.1-.6-.3-2.5-.9-4.8-3-1.8-1.6-3-3.5-3.3-4.1-.3-.6 0-.9.3-1.2.3-.3.6-.7.9-1 .1-.1.1-.2.2-.3.1-.2.2-.4.4-.7.2-.4.1-.7 0-1-.1-.3-1.4-3.2-1.9-4.4-.5-1.2-1-1-1.4-1-.3 0-.7-.1-1.1-.1-.4 0-1.1.1-1.6.7-.6.6-2.1 2-2.1 5 0 .7.1 1.4.3 2 .6 2.1 1.9 3.8 2.1 4.1.3.4 4.2 6.6 10.3 9 6.1 2.4 6.1 1.6 7.2 1.5 1.1-.1 3.6-1.4 4.1-2.8.5-1.4.5-2.6.4-2.8-.3-.3-.7-.4-1.3-.7z"
    })]
  })]
});

const IconsPack = {
  alsfairLogo,
  stayIcon,
  offerIcon,
  dineIcon,
  entertainmentIcon,
  meetnEventIcon,
  healthnWellnessIcon,
  photoGallery,
  blogIcon,
  brandStoryIcon,
  alsafirRings,
  arrowIcon,
  downIcon,
  addressIcon,
  callIcon,
  emailIcon,
  mailIcon,
  faxIcon,
  instagramIcon,
  whatsappIcon
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (IconsPack);

/***/ })

};
;