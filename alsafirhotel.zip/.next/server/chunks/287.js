exports.id = 287;
exports.ids = [287];
exports.modules = {

/***/ 3535:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(1664);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(5282);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__);




const ListingCard = ({
  title,
  description,
  src,
  learnMoreUrl,
  enableLearnMoreButton
}) => {
  return /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxs)("div", {
    className: "space-y-2 scale-95 hover:scale-100 transition-all duration-1000 border-b-2 p-2 border-primary ",
    children: [/*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxs)("div", {
      className: "h-96 w-auto relative",
      children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.jsx("img", {
        className: "rounded h-96 w-full object-cover",
        src: `/images/${src}`
      }), enableLearnMoreButton ? /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.jsx("div", {
        className: "absolute bottom-5 w-full flex justify-center items-center space-x-4 ",
        children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.jsx(next_link__WEBPACK_IMPORTED_MODULE_0__.default, {
          href: `${learnMoreUrl}`,
          children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.jsx("a", {
            className: "uppercase font-mark text-white text-center py-2 px-4 rounded bg-primary hover:bg-secondary",
            children: "Learn More"
          })
        })
      }) : null]
    }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.jsx("h3", {
      className: "font-markbook text-lg uppercase text-primary",
      children: title
    }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.jsx("p", {
      className: "text-base font-mark",
      children: description
    })]
  });
};

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (ListingCard);

/***/ }),

/***/ 3551:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "eu": () => (/* binding */ fadeInUp),
/* harmony export */   "$k": () => (/* binding */ slideInRight),
/* harmony export */   "EY": () => (/* binding */ stagger)
/* harmony export */ });
const fadeInUp = {
  initial: {
    opacity: 0,
    y: "10vh"
  },
  animate: {
    opacity: 1,
    y: 0,
    transition: {
      ease: "easeOut",
      duration: 1
    }
  },
  exit: {
    opacity: 0
  }
};
const slideInRight = {
  initial: {
    opacity: 0,
    x: "-10vh"
  },
  animate: {
    opacity: 1,
    x: 0,
    transition: {
      ease: "easeOut",
      duration: 1
    }
  },
  exit: {
    opacity: 0
  }
};
const stagger = {
  animate: {
    transition: {
      staggerChildren: 0.05
    }
  }
};

/***/ }),

/***/ 2431:
/***/ (() => {

/* (ignored) */

/***/ })

};
;