exports.id = 350;
exports.ids = [350];
exports.modules = {

/***/ 6694:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "R": () => (/* binding */ ImageData)
/* harmony export */ });
const ImageData = [{
  id: 1,
  image: "/images/homepage/homeCoverImage01.jpg"
}, {
  id: 2,
  image: "/images/health/indoorpool.jpg"
}, {
  id: 3,
  image: "/images/homepage/Inside-Al-Safir-Hotel.jpg"
}, {
  id: 4,
  image: "/images/gallery/delux-twin.jpg"
}, {
  id: 5,
  image: "/images/staypage/single-room-alsafir-front-view.jpg"
}, {
  id: 6,
  image: "/images/staypage/twin-room-inside.jpg"
}];

/***/ }),

/***/ 3551:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "eu": () => (/* binding */ fadeInUp),
/* harmony export */   "$k": () => (/* binding */ slideInRight),
/* harmony export */   "EY": () => (/* binding */ stagger)
/* harmony export */ });
const fadeInUp = {
  initial: {
    opacity: 0,
    y: "10vh"
  },
  animate: {
    opacity: 1,
    y: 0,
    transition: {
      ease: "easeOut",
      duration: 1
    }
  },
  exit: {
    opacity: 0
  }
};
const slideInRight = {
  initial: {
    opacity: 0,
    x: "-10vh"
  },
  animate: {
    opacity: 1,
    x: 0,
    transition: {
      ease: "easeOut",
      duration: 1
    }
  },
  exit: {
    opacity: 0
  }
};
const stagger = {
  animate: {
    transition: {
      staggerChildren: 0.05
    }
  }
};

/***/ }),

/***/ 2431:
/***/ (() => {

/* (ignored) */

/***/ })

};
;