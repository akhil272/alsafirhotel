exports.id = 149;
exports.ids = [149];
exports.modules = {

/***/ 3627:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(6731);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_0__);


const useTranslation = (en, ar) => {
  const router = (0,next_router__WEBPACK_IMPORTED_MODULE_0__.useRouter)();
  const {
    locale
  } = router;
  const t = locale === "en" ? en : ar;
  return t;
};

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (useTranslation);

/***/ }),

/***/ 5880:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({
  offers: "عروض",
  dine: "تناول العشاء",
  stay: "البقاء",
  entertainment: "تسلية",
  meet: "لقاء وحدث",
  health: "الصحة والعافية",
  photogallery: "معرض الصور",
  blog: "مقالات",
  brandstory: "قصة العلامة التجارية"
});

/***/ }),

/***/ 4829:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({
  offers: "offers",
  dine: "dine",
  stay: "stay",
  entertainment: "entertainment",
  meet: "meet & event",
  health: "health & wellness",
  photogallery: "photo gallery",
  blog: "blog",
  brandstory: "brand story"
});

/***/ }),

/***/ 2431:
/***/ (() => {

/* (ignored) */

/***/ })

};
;