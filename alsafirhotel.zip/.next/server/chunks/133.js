"use strict";
exports.id = 133;
exports.ids = [133];
exports.modules = {

/***/ 4960:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({
  title: "البقاء",
  subtitle: "أسلوب متقن ورائع",
  p1: "يتميز فندق السفير بطرازه الرائع والرائع ، ويوفر إقامة كلاسيكية. مع 126 غرفة وجناحًا مجهزًا بشكل أنيق يجمع بذكاء بين السحر ووسائل الراحة الحديثة الرصينة.",
  p2: "إنه يوفر مزيجًا أنيقًا من الفخامة الكلاسيكية والأسلوب المعاصر ويخلق تجربة متنوعة مع غرف فندقية مصممة بإتقان. تسمح جميع أماكن الإقامة في الغرف بمرافق بديهية وأرواح متجددة لتوفير فترة راحة مريحة من ضجيج وحيوية المدينة.",
  p3: "تهدف كل تفاصيل إقامتك معنا إلى تقدير رغباتك الشخصية والاحتفاء بها. في كل خطوة على الطريق ، خبراتنا مكرسة لتقديم خدمة مراعية ومصممة خصيصًا لجعلها إقامة استثنائية.",
  room1: "غرف ديلوكس مفردة",
  room1description: "ادخل إلى غرف نوم الضيوف الفسيحة البالغة مساحتها 29 مترًا مربعًا واستمتع بتجربة البذخ في أفضل حالاتها. تحتوي جميع الغرف على سرير بحجم كينغ ومساحة خزانة واسعة وحمام مع تجديد يومي بوسائل الراحة. الغرفة مجهزة أيضًا بمكتب عمل وتتمتع بإطلالة مذهلة على المدينة."
});

/***/ }),

/***/ 9858:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({
  title: "Stay",
  subtitle: "Sophistic and splendid style",
  p1: "Sophistic and splendid style Al Safir Hotel offers a classic stay. With 126 stylishly appointed rooms and suites that cleverly combine charm with discreet modern amenities.",
  p2: "It offers an elegant combination of classic luxury and contemporary style and creates a diverse experience with proficiently designed hotel rooms. All room accommodations allow for intuitive facility and replenished spirits to offer a soothing respite from the buzz and verve of the city.",
  p3: "Every detail of your stay with us is intended to cherish and celebrate your personal desires. Every step of the way, our expertise are dedicated to offer a considerate, custom-made service to make it an exceptional stay.",
  room1: "DELUXE SINGLE ROOMS",
  room1description: "Step inside the classy spacious 29sqm, guest bedrooms and experience extravagance at its best. All rooms have king-sized bed, ample closet space and a bathroom with daily replenish of amenities. The room is also equipped with a work desk and has startling city view."
});

/***/ })

};
;