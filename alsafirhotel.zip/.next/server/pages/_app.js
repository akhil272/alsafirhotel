"use strict";
(() => {
var exports = {};
exports.id = 888;
exports.ids = [888];
exports.modules = {

/***/ 4332:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ _app)
});

// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(9297);
;// CONCATENATED MODULE: external "@headlessui/react"
const react_namespaceObject = require("@headlessui/react");
// EXTERNAL MODULE: external "next/router"
var router_ = __webpack_require__(6731);
// EXTERNAL MODULE: ./components/ImageSlider/index.tsx
var ImageSlider = __webpack_require__(5592);
// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(5282);
;// CONCATENATED MODULE: ./components/BookNow/Counter.tsx



const plus = /*#__PURE__*/jsx_runtime_.jsx("svg", {
  xmlns: "http://www.w3.org/2000/svg",
  fill: "currentColor",
  className: "h-5 w-5",
  viewBox: "0 0 20 20",
  children: /*#__PURE__*/jsx_runtime_.jsx("path", {
    fillRule: "evenodd",
    d: "M10 18a8 8 0 100-16 8 8 0 000 16zm1-11a1 1 0 10-2 0v2H7a1 1 0 100 2h2v2a1 1 0 102 0v-2h2a1 1 0 100-2h-2V7z",
    clipRule: "evenodd"
  })
});

const minus = /*#__PURE__*/jsx_runtime_.jsx("svg", {
  xmlns: "http://www.w3.org/2000/svg",
  fill: "currentColor",
  className: "h-5 w-5",
  viewBox: "0 0 20 20",
  children: /*#__PURE__*/jsx_runtime_.jsx("path", {
    fillRule: "evenodd",
    d: "M10 18a8 8 0 100-16 8 8 0 000 16zM7 9a1 1 0 000 2h6a1 1 0 100-2H7z",
    clipRule: "evenodd"
  })
});

const Counter = ({
  categories,
  count,
  setCount
}) => {
  const handleChange = type => {
    if (type === "dec") {
      count > 0 && setCount(count - 1);
    } else {
      count < 10 && setCount(count + 1);
    }
  };

  return /*#__PURE__*/jsx_runtime_.jsx("div", {
    className: "bg-opacity-40 bg-primary w-full  rounded-sm ",
    children: /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
      className: "flex flex-col items-center justify-center -space-y-3 w-full",
      children: [/*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
        className: " divide-x divide-gray-400 h-14 w-full grid grid-cols-3 content-center  rtl:divide-x-0",
        children: [/*#__PURE__*/jsx_runtime_.jsx("button", {
          className: " text-primary flex items-center justify-center",
          onClick: () => handleChange("dec"),
          children: minus
        }), /*#__PURE__*/jsx_runtime_.jsx("div", {
          className: "  flex items-center text-2xl justify-center",
          children: count
        }), /*#__PURE__*/jsx_runtime_.jsx("button", {
          className: " text-primary flex items-center justify-center",
          onClick: () => handleChange("inc"),
          children: plus
        })]
      }), /*#__PURE__*/jsx_runtime_.jsx("div", {
        className: "font-mark font-light",
        children: categories
      })]
    })
  });
};

/* harmony default export */ const BookNow_Counter = (Counter);
;// CONCATENATED MODULE: ./components/BookNow/RoomsCount.tsx





const roomCounts = [{
  id: 1,
  title: "1"
}, {
  id: 2,
  title: "2"
}, {
  id: 3,
  title: "3"
}];

const RoomsCount = ({
  count,
  setCount
}) => {
  const {
    0: isOpen,
    1: setIsOpen
  } = (0,external_react_.useState)(false);

  function closeModal() {
    setIsOpen(false);
  }

  const defaultClass = "flex flex-col h-14 w-full bg-primary items-center justify-center bg-opacity-30 rounded-md ";
  const userSelectedClass = "flex flex-col h-14 w-full bg-primary items-center justify-center  rounded-md";

  const handleSelection = roomCount => {
    setCount(roomCount.id);
  };

  const handleAddMoreRooms = () => {
    setIsOpen(!isOpen);

    if (count < 3) {
      setCount(4);
    }
  };

  return /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
    id: "roomCount",
    className: "flex justify-between gap-2 relative  ",
    children: [roomCounts.map(roomCount => /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
      style: {
        borderWidth: "1px",
        borderColor: "#C3A47D"
      },
      className: `${roomCount.id === count ? userSelectedClass : defaultClass}`,
      children: [/*#__PURE__*/jsx_runtime_.jsx("button", {
        name: roomCount.title,
        onClick: () => handleSelection(roomCount),
        className: "text-2xl",
        children: roomCount.title
      }), /*#__PURE__*/jsx_runtime_.jsx("label", {
        children: "Room"
      })]
    }, roomCount.id)), /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
      style: {
        borderWidth: "1px",
        borderColor: "#C3A47D"
      },
      onClick: handleAddMoreRooms,
      className: `${count >= 4 ? userSelectedClass : defaultClass}`,
      children: [/*#__PURE__*/jsx_runtime_.jsx("button", {
        className: "text-2xl",
        type: "button",
        children: count > 3 ? count : "+"
      }), /*#__PURE__*/jsx_runtime_.jsx("label", {
        children: "Room"
      })]
    }), /*#__PURE__*/jsx_runtime_.jsx(react_namespaceObject.Transition, {
      appear: true,
      show: isOpen,
      as: external_react_.Fragment,
      children: /*#__PURE__*/jsx_runtime_.jsx(react_namespaceObject.Dialog, {
        as: "div",
        className: "fixed inset-0 z-10 overflow-y-auto",
        onClose: closeModal,
        children: /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
          className: "min-h-screen px-4 text-center",
          children: [/*#__PURE__*/jsx_runtime_.jsx(react_namespaceObject.Transition.Child, {
            as: external_react_.Fragment,
            enter: "ease-out duration-300",
            enterFrom: "opacity-0",
            enterTo: "opacity-100",
            leave: "ease-in duration-200",
            leaveFrom: "opacity-100",
            leaveTo: "opacity-0",
            children: /*#__PURE__*/jsx_runtime_.jsx(react_namespaceObject.Dialog.Overlay, {
              className: "fixed inset-0"
            })
          }), /*#__PURE__*/jsx_runtime_.jsx("span", {
            className: "inline-block h-screen align-middle",
            "aria-hidden": "true",
            children: "\u200B"
          }), /*#__PURE__*/jsx_runtime_.jsx(react_namespaceObject.Transition.Child, {
            as: external_react_.Fragment,
            enter: "ease-out duration-300",
            enterFrom: "opacity-0 scale-95",
            enterTo: "opacity-100 scale-100",
            leave: "ease-in duration-200",
            leaveFrom: "opacity-100 scale-100",
            leaveTo: "opacity-0 scale-95",
            children: /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
              className: "inline-block w-full max-w-md p-6 my-8 overflow-hidden text-left align-middle transition-all transform bg-black shadow-xl rounded-2xl",
              children: [/*#__PURE__*/jsx_runtime_.jsx("div", {
                className: "mt-2",
                children: /*#__PURE__*/jsx_runtime_.jsx(BookNow_Counter, {
                  categories: "Rooms",
                  count: count,
                  setCount: setCount
                })
              }), /*#__PURE__*/jsx_runtime_.jsx("div", {
                className: "mt-4",
                children: /*#__PURE__*/jsx_runtime_.jsx("button", {
                  type: "button",
                  className: "inline-flex uppercase justify-center px-4 py-2 text-sm font-mark text-white bg-primary border border-transparent rounded-md w-full",
                  onClick: closeModal,
                  children: "Update Rooms Count"
                })
              })]
            })
          })]
        })
      })
    })]
  });
};

/* harmony default export */ const BookNow_RoomsCount = (RoomsCount);
;// CONCATENATED MODULE: ./components/BookNow/RoomSelector.tsx



const RoomSelector = ({
  selectedRoom,
  setSelectedRoom
}) => {
  const defaultClass = "bg-primary uppercase w-full p-1 rounded-sm flex items-center justify-center";
  const userSelectedClass = "bg-primary uppercase bg-opacity-40 font-mark w-full p-1 rounded-sm flex items-center justify-center";
  const roomTypes = [{
    id: 1,
    title: "Deluxe Single"
  }, {
    id: 2,
    title: "Deluxe Twin"
  }];

  const handleSelection = roomType => {
    setSelectedRoom(roomType.id);
  };

  return /*#__PURE__*/jsx_runtime_.jsx("div", {
    className: "flex justify-center items-center text-md font-mark font-light mt-4 border-2 border-primary p-0.5 rounded-sm ",
    children: roomTypes.map(roomType => /*#__PURE__*/jsx_runtime_.jsx("div", {
      className: `${roomType.id === selectedRoom ? defaultClass : userSelectedClass}`,
      children: /*#__PURE__*/jsx_runtime_.jsx("button", {
        name: roomType.title,
        onClick: () => handleSelection(roomType),
        children: roomType.title
      })
    }, roomType.id))
  });
};

/* harmony default export */ const BookNow_RoomSelector = (RoomSelector);
// EXTERNAL MODULE: ./public/images/IconsPack.js
var IconsPack = __webpack_require__(5023);
;// CONCATENATED MODULE: external "react-date-range"
const external_react_date_range_namespaceObject = require("react-date-range");
;// CONCATENATED MODULE: ./components/BookNow/CalenderTransition.tsx



 // main style file

 // theme css file




const CalenderTransition = ({
  openModal,
  setOpenModal,
  handleChange,
  minDate
}) => {
  return /*#__PURE__*/jsx_runtime_.jsx(react_namespaceObject.Transition, {
    appear: true,
    show: openModal,
    as: external_react_.Fragment,
    children: /*#__PURE__*/jsx_runtime_.jsx(react_namespaceObject.Dialog, {
      as: "div",
      className: "fixed inset-0 z-10 overflow-y-auto",
      onClose: () => setOpenModal(!openModal),
      children: /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
        className: "min-h-screen px-4 text-center",
        children: [/*#__PURE__*/jsx_runtime_.jsx(react_namespaceObject.Transition.Child, {
          as: external_react_.Fragment,
          enter: "ease-out duration-300",
          enterFrom: "opacity-0",
          enterTo: "opacity-100",
          leave: "ease-in duration-200",
          leaveFrom: "opacity-100",
          leaveTo: "opacity-0",
          children: /*#__PURE__*/jsx_runtime_.jsx(react_namespaceObject.Dialog.Overlay, {
            className: "fixed inset-0"
          })
        }), /*#__PURE__*/jsx_runtime_.jsx("span", {
          className: "inline-block h-screen align-middle",
          "aria-hidden": "true",
          children: "\u200B"
        }), /*#__PURE__*/jsx_runtime_.jsx(react_namespaceObject.Transition.Child, {
          as: external_react_.Fragment,
          enter: "ease-out duration-300",
          enterFrom: "opacity-0 scale-95",
          enterTo: "opacity-100 scale-100",
          leave: "ease-in duration-200",
          leaveFrom: "opacity-100 scale-100",
          leaveTo: "opacity-0 scale-95",
          children: /*#__PURE__*/jsx_runtime_.jsx("div", {
            className: "inline-block max-w-md align-middle transition-all transform  shadow-xl ",
            children: /*#__PURE__*/jsx_runtime_.jsx(external_react_date_range_namespaceObject.Calendar, {
              minDate: minDate,
              onChange: handleChange,
              showMonthAndYearPickers: false,
              rangeColors: ["#C3A47D"]
            })
          })
        })]
      })
    })
  });
};

/* harmony default export */ const BookNow_CalenderTransition = (CalenderTransition);
;// CONCATENATED MODULE: ./components/BookNow/DatePicker.tsx
 // main style file

 // theme css file







const DatePicker = ({
  startDate,
  setStartDate,
  endDate,
  setEndDate
}) => {
  const {
    0: openDateModal,
    1: setOpenDateModal
  } = (0,external_react_.useState)(false);
  const {
    0: openEndDateModal,
    1: setOpenEndDateModal
  } = (0,external_react_.useState)(false);

  function formattedStartDate(d = startDate) {
    return [d.getDate(), d.getMonth() + 1, d.getFullYear()].map(n => n < 10 ? `0${n}` : `${n}`).join("/");
  }

  function formattedEndDate(d = endDate) {
    return [d.getDate(), d.getMonth() + 1, d.getFullYear()].map(n => n < 10 ? `0${n}` : `${n}`).join("/");
  }

  const handleStartDate = date => {
    setStartDate(date);
    setEndDate(new Date(date.getTime() + 1000 * 60 * 60 * 24));
    setOpenDateModal(!openDateModal);
  };

  const handleEndDate = date => {
    setEndDate(date);
    setOpenEndDateModal(!openEndDateModal);
  };

  return /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
    className: "flex relative items-start text-lg font-mark font-light mt-4 border-b-2 border-b-primary  p-0.5 rounded-sm ",
    children: [/*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
      className: "flex flex-col w-1/2",
      children: [/*#__PURE__*/jsx_runtime_.jsx("div", {
        className: "text-xs ",
        children: "Start Date"
      }), /*#__PURE__*/jsx_runtime_.jsx("h5", {
        onClick: () => setOpenDateModal(!openDateModal),
        children: formattedStartDate()
      }), /*#__PURE__*/jsx_runtime_.jsx(BookNow_CalenderTransition, {
        handleChange: handleStartDate,
        openModal: openDateModal,
        setOpenModal: setOpenDateModal,
        minDate: new Date()
      })]
    }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
      className: "flex flex-col ",
      children: [/*#__PURE__*/jsx_runtime_.jsx("div", {
        className: "text-xs",
        children: "End Date"
      }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("h5", {
        onClick: () => setOpenEndDateModal(!openEndDateModal),
        children: [formattedEndDate(), /*#__PURE__*/jsx_runtime_.jsx("span", {
          className: "absolute right-4 rtl:hidden",
          children: IconsPack/* default.downIcon */.Z.downIcon
        })]
      }), /*#__PURE__*/jsx_runtime_.jsx(BookNow_CalenderTransition, {
        handleChange: handleEndDate,
        openModal: openEndDateModal,
        setOpenModal: setOpenEndDateModal,
        minDate: startDate
      })]
    })]
  });
};

/* harmony default export */ const BookNow_DatePicker = (DatePicker);
;// CONCATENATED MODULE: ./components/BookNow/ListBoxCounter.tsx






const ListBoxCounter = ({
  title,
  counter
}) => {
  const {
    0: selected,
    1: setSelected
  } = (0,external_react_.useState)(counter[0]);
  return /*#__PURE__*/jsx_runtime_.jsx("div", {
    className: "transition duration-1000 hover:bg-gray-900",
    children: /*#__PURE__*/jsx_runtime_.jsx(react_namespaceObject.Listbox, {
      value: selected,
      onChange: setSelected,
      children: /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
        className: "relative mt-1 ",
        children: [/*#__PURE__*/(0,jsx_runtime_.jsxs)(react_namespaceObject.Listbox.Button, {
          className: "relative w-full py-2 pl-3 pr-10  ",
          children: [/*#__PURE__*/(0,jsx_runtime_.jsxs)("span", {
            className: "block truncate",
            children: [selected.content, " ", title]
          }), /*#__PURE__*/jsx_runtime_.jsx("span", {
            className: "absolute inset-y-0 right-0 flex items-center pr-2 pointer-events-none"
          })]
        }), /*#__PURE__*/jsx_runtime_.jsx(react_namespaceObject.Transition, {
          as: external_react_.Fragment,
          leave: "transition ease-in duration-100",
          leaveFrom: "opacity-100",
          leaveTo: "opacity-0",
          children: /*#__PURE__*/jsx_runtime_.jsx(react_namespaceObject.Listbox.Options, {
            className: "absolute w-full bottom-12 py-1 bg-black bg-opacity-70 text-center ",
            children: counter.map((count, countIdx) => /*#__PURE__*/jsx_runtime_.jsx(react_namespaceObject.Listbox.Option, {
              className: ({
                active
              }) => `${active ? "bg-primary" : "text-white"}
                          cursor-default select-none relative py-2 `,
              value: count,
              children: ({
                selected,
                active
              }) => /*#__PURE__*/jsx_runtime_.jsx(jsx_runtime_.Fragment, {
                children: /*#__PURE__*/jsx_runtime_.jsx("span", {
                  className: `${selected ? "font-medium" : "font-normal"} block truncate`,
                  children: count.content
                })
              })
            }, countIdx))
          })
        })]
      })
    })
  });
};

/* harmony default export */ const BookNow_ListBoxCounter = (ListBoxCounter);
;// CONCATENATED MODULE: ./components/BookNow/CallNowButton.tsx





const CallNowButton = () => {
  const {
    0: isOpen,
    1: setIsOpen
  } = (0,external_react_.useState)(false);

  const handleCallNow = () => {
    setIsOpen(!isOpen);
  };

  function closeModal() {
    setIsOpen(false);
  }

  return /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
    children: [/*#__PURE__*/jsx_runtime_.jsx("div", {
      onClick: handleCallNow,
      className: "absolute bg-black flex ring-2 ring-primary justify-center bg-opacity-80 hover:bg-opacity-100 items-center h-14 w-14 rounded-full bottom-4 right-4",
      children: /*#__PURE__*/jsx_runtime_.jsx("img", {
        className: "object-contain h-10 w-10  ",
        src: "/images/icons/call-icon-01.svg"
      })
    }), /*#__PURE__*/jsx_runtime_.jsx(react_namespaceObject.Transition, {
      appear: true,
      show: isOpen,
      as: external_react_.Fragment,
      children: /*#__PURE__*/jsx_runtime_.jsx(react_namespaceObject.Dialog, {
        as: "div",
        className: "fixed inset-0 z-10 overflow-y-auto",
        onClose: closeModal,
        children: /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
          className: "min-h-screen px-4 text-center",
          children: [/*#__PURE__*/jsx_runtime_.jsx(react_namespaceObject.Transition.Child, {
            as: external_react_.Fragment,
            enter: "ease-out duration-300",
            enterFrom: "opacity-0",
            enterTo: "opacity-100",
            leave: "ease-in duration-200",
            leaveFrom: "opacity-100",
            leaveTo: "opacity-0",
            children: /*#__PURE__*/jsx_runtime_.jsx(react_namespaceObject.Dialog.Overlay, {
              className: "fixed inset-0"
            })
          }), /*#__PURE__*/jsx_runtime_.jsx("span", {
            className: "inline-block h-screen align-middle",
            "aria-hidden": "true",
            children: "\u200B"
          }), /*#__PURE__*/jsx_runtime_.jsx(react_namespaceObject.Transition.Child, {
            as: external_react_.Fragment,
            enter: "ease-out duration-300",
            enterFrom: "opacity-0 scale-95",
            enterTo: "opacity-100 scale-100",
            leave: "ease-in duration-200",
            leaveFrom: "opacity-100 scale-100",
            leaveTo: "opacity-0 scale-95",
            children: /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
              className: "inline-block w-full max-w-md p-6 my-8 overflow-hidden text-left align-middle transition-all transform bg-black bg-opacity-90 shadow-xl rounded-2xl",
              children: [/*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
                className: "flex flex-col justify-center items-start",
                children: [/*#__PURE__*/jsx_runtime_.jsx("label", {
                  className: "uppercase font-markbook text-2xl",
                  children: "Contact Us"
                }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
                  className: "pt-4 w-full hover:text-primary hover:pl-2 transition-all duration-1000 flex flex-col",
                  children: [/*#__PURE__*/jsx_runtime_.jsx("label", {
                    className: "text-xs",
                    children: "TOLL FREE NUMBER"
                  }), /*#__PURE__*/jsx_runtime_.jsx("a", {
                    className: "text-xl",
                    href: "tel:+97317827999",
                    children: "+973 1782 7999"
                  })]
                }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
                  className: "pt-4 w-full hover:text-primary hover:pl-2 transition-all duration-1000 flex flex-col",
                  children: [/*#__PURE__*/jsx_runtime_.jsx("label", {
                    className: "text-xs",
                    children: "EMAIL"
                  }), /*#__PURE__*/jsx_runtime_.jsx("a", {
                    className: "text-xl",
                    href: "mailto:hello@alsafirhotel.com",
                    children: "hello@alsafirhotel.com"
                  })]
                }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
                  className: "pt-4 w-full hover:text-primary hover:pl-2 transition-all duration-1000 flex flex-col",
                  children: [/*#__PURE__*/jsx_runtime_.jsx("label", {
                    className: "text-xs",
                    children: "WHATSAPP"
                  }), /*#__PURE__*/jsx_runtime_.jsx("a", {
                    className: "text-xl",
                    href: "https://wa.me/+97333644411?text=I%20like%20to%20book%20rooms%20in%20AlSafir%20Hotel",
                    children: "+973 33644411"
                  })]
                })]
              }), /*#__PURE__*/jsx_runtime_.jsx("div", {
                className: "mt-4",
                children: /*#__PURE__*/jsx_runtime_.jsx("button", {
                  type: "button",
                  className: "inline-flex hover:bg-opacity-80 transition duration-1000 justify-center px-4 py-2 text-xl uppercase font-mark tracking-widest text-white bg-primary border border-transparent rounded-md w-full",
                  onClick: closeModal,
                  children: "Close"
                })
              })]
            })
          })]
        })
      })
    })]
  });
};

/* harmony default export */ const BookNow_CallNowButton = (CallNowButton);
;// CONCATENATED MODULE: ./components/BookNow/ScrollBookNow.tsx



 // main style file

 // theme css file





const counter = [{
  content: "1"
}, {
  content: "2"
}, {
  content: "3"
}, {
  content: "4"
}, {
  content: "5"
}, {
  content: "6"
}, {
  content: "7"
}, {
  content: "8"
}, {
  content: "9"
}, {
  content: "10"
}];
const roomTypes = [{
  content: "Deluxe Twin"
}, {
  content: "Deluxe Double"
}];

const ScrollBookNow_DatePicker = ({
  startDate,
  endDate,
  setStartDate,
  setEndDate
}) => {
  const {
    0: openStartDateModal,
    1: setOpenStartDateModal
  } = (0,external_react_.useState)(true);
  const {
    0: openEndDateModal,
    1: setOpenEndDateModal
  } = (0,external_react_.useState)(true);

  function formattedStartDate(d = startDate) {
    let {
      day,
      month,
      year
    } = new Intl.DateTimeFormat("en", {
      day: "2-digit",
      month: "short",
      year: "numeric"
    }).formatToParts(d).reduce((acc, part) => {
      if (part.type != "literal") {
        acc[part.type] = part.value;
      }

      return acc;
    }, Object.create(null));
    return `${day}-${month}-${year}`;
  }

  function formattedEndDate(d = endDate) {
    let {
      day,
      month,
      year
    } = new Intl.DateTimeFormat("en", {
      day: "2-digit",
      month: "short",
      year: "numeric"
    }).formatToParts(d).reduce((acc, part) => {
      if (part.type != "literal") {
        acc[part.type] = part.value;
      }

      return acc;
    }, Object.create(null));
    return `${day}-${month}-${year}`;
  }

  const handleStartDate = date => {
    setStartDate(date);
    setOpenStartDateModal(!openStartDateModal);
    setOpenEndDateModal(true);
  };

  const handleEndDate = date => {
    setEndDate(date);
    setOpenEndDateModal(!openEndDateModal);
    setOpenStartDateModal(true);
  };

  return /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
    className: "flex h-full justify-center items-center relative ",
    children: [/*#__PURE__*/(0,jsx_runtime_.jsxs)("label", {
      className: "transition duration-1000 hover:bg-gray-900 w-full h-full text-center flex items-center ",
      onClick: () => setOpenStartDateModal(!openStartDateModal),
      children: [formattedStartDate(), "--"]
    }), !openStartDateModal && /*#__PURE__*/jsx_runtime_.jsx("div", {
      className: "absolute bottom-12 ",
      children: /*#__PURE__*/jsx_runtime_.jsx(external_react_date_range_namespaceObject.Calendar, {
        minDate: new Date(),
        onChange: handleStartDate,
        showMonthAndYearPickers: false
      })
    }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("label", {
      className: "transition duration-1000 hover:bg-gray-900 w-full h-full text-center flex items-center ",
      onClick: () => setOpenEndDateModal(!openEndDateModal),
      children: ["--", formattedEndDate()]
    }), !openEndDateModal && /*#__PURE__*/jsx_runtime_.jsx("div", {
      className: "absolute bottom-12",
      children: /*#__PURE__*/jsx_runtime_.jsx(external_react_date_range_namespaceObject.Calendar, {
        minDate: startDate,
        onChange: handleEndDate,
        showMonthAndYearPickers: false
      })
    })]
  });
};

const ScrollBookNow = () => {
  const router = (0,router_.useRouter)();
  const {
    0: startDate,
    1: setStartDate
  } = (0,external_react_.useState)(new Date());
  const {
    0: endDate,
    1: setEndDate
  } = (0,external_react_.useState)(new Date());

  const handleBookNow = () => {
    const checkInDate = new Intl.DateTimeFormat("en-GB", {
      dateStyle: "medium"
    }).format(startDate).replace(/ /g, "%20");
    const checkOutDate = new Intl.DateTimeFormat("en-GB", {
      dateStyle: "medium"
    }).format(endDate).replace(/ /g, "%20");
    const countAdults = 1;
    const countChildren = 1;
    const countRooms = 1; //rate triger integration disabled
    // router.push(
    //   `https://alsafirhotel.seebooking.com/#/roomlist?checkin=${checkInDate}&checkout=${checkOutDate}&lang=EN&noOfAdults=${countAdults}&noOfChildren=${countChildren}&noOfRooms=${countRooms}&property_id=554769`
    // );

    router.push("/contactus");
  };

  return /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
    className: "flex w-screen justify-between items-center pl-20",
    children: [/*#__PURE__*/jsx_runtime_.jsx(ScrollBookNow_DatePicker, {
      startDate: startDate,
      endDate: endDate,
      setStartDate: setStartDate,
      setEndDate: setEndDate
    }), /*#__PURE__*/jsx_runtime_.jsx(BookNow_ListBoxCounter, {
      title: "Rooms",
      counter: roomTypes
    }), /*#__PURE__*/jsx_runtime_.jsx(BookNow_ListBoxCounter, {
      title: "Rooms",
      counter: counter
    }), /*#__PURE__*/jsx_runtime_.jsx(BookNow_ListBoxCounter, {
      title: "Adults",
      counter: counter
    }), /*#__PURE__*/jsx_runtime_.jsx(BookNow_ListBoxCounter, {
      title: "Children",
      counter: counter
    }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
      className: "transition duration-1000 hover:bg-black hover:text-primary text-white bg-black h-full  pl-20 pr-20 flex justify-center items-center",
      children: [/*#__PURE__*/jsx_runtime_.jsx("button", {
        onClick: handleBookNow,
        className: " text-xl",
        children: "BOOK NOW"
      }), /*#__PURE__*/jsx_runtime_.jsx(BookNow_CallNowButton, {})]
    })]
  });
};

/* harmony default export */ const BookNow_ScrollBookNow = (ScrollBookNow);
;// CONCATENATED MODULE: ./locales/booknow/en.ts
/* harmony default export */ const en = ({
  title: "BOOK YOUR ROOM",
  room: "Room",
  adult: "Adults",
  children: "Children",
  startdate: "Start Date",
  enddate: "End Date",
  booknow: "Book Now",
  deluxtwin: "Deluxe Twin",
  deluxsingle: "Deluxe Single"
});
;// CONCATENATED MODULE: ./locales/booknow/ar.ts
/* harmony default export */ const ar = ({
  title: "احجز غرفتك",
  room: "غرف",
  adult: "الكبار",
  children: "أطفال",
  startdate: "تاريخ البدء",
  enddate: "تاريخ الانتهاء",
  booknow: "احجز الآن",
  deluxtwin: "ديلوكس توأم",
  deluxsingle: "ديلوكس مفرد"
});
;// CONCATENATED MODULE: ./components/BookNow/index.tsx















const image1 = "/images/homepage/homeCoverImage01.jpg";
const image2 = "/images/staypage/twin-room-inside.jpg";

const BookNow = () => {
  const {
    0: open,
    1: setOpen
  } = (0,external_react_.useState)(false);
  const {
    0: show,
    1: setShow
  } = (0,external_react_.useState)(true);
  const router = (0,router_.useRouter)();
  const {
    locale
  } = router;
  const t = locale === "en" ? en : ar;

  const controlBookNow = () => {
    if (window.scrollY > 200) {
      setShow(false);
    } else {
      setShow(true);
    }
  };

  (0,external_react_.useEffect)(() => {
    window.addEventListener("scroll", controlBookNow);
    return () => {
      window.removeEventListener("scroll", controlBookNow);
    };
  }, []);

  const openModal = () => {
    setOpen(prev => !prev);
  }; // States Management
  //RoomSelector
  // Room types defined in room selector


  const {
    0: selectedRoom,
    1: setSelectedRoom
  } = (0,external_react_.useState)(1); //Date

  const {
    0: startDate,
    1: setStartDate
  } = (0,external_react_.useState)(new Date());
  const {
    0: endDate,
    1: setEndDate
  } = (0,external_react_.useState)(new Date(new Date().getTime() + 1000 * 60 * 60 * 24)); //Counter

  const {
    0: countAdults,
    1: setCountAdults
  } = (0,external_react_.useState)(1);
  const {
    0: countChildren,
    1: setCountChildren
  } = (0,external_react_.useState)(0);
  const {
    0: countRooms,
    1: setCountRooms
  } = (0,external_react_.useState)(1);

  const handleBookNow = () => {
    const checkInDate = new Intl.DateTimeFormat("en-GB", {
      dateStyle: "medium"
    }).format(startDate).replace(/ /g, "%20");
    const checkOutDate = new Intl.DateTimeFormat("en-GB", {
      dateStyle: "medium"
    }).format(endDate).replace(/ /g, "%20"); //  rate triger integration disabled
    // router.push(
    //   `https://alsafirhotel.seebooking.com/#/roomlist?checkin=${checkInDate}&checkout=${checkOutDate}&lang=EN&noOfAdults=${countAdults}&noOfChildren=${countChildren}&noOfRooms=${countRooms}&property_id=554769`
    // );

    router.push("/contactus");
  };

  return /*#__PURE__*/(0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
    children: [/*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
      className: "block lg:hidden",
      children: [/*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
        className: "transition duration-1000 hover:bg-black font-mark tracking-widest hover:text-primary fixed bottom-0 text-white bg-primary min-w-full text-center text-2xl p-2",
        children: [/*#__PURE__*/jsx_runtime_.jsx("button", {
          onClick: openModal,
          children: t.booknow
        }), /*#__PURE__*/jsx_runtime_.jsx(BookNow_CallNowButton, {})]
      }), /*#__PURE__*/jsx_runtime_.jsx(react_namespaceObject.Transition.Root, {
        show: open,
        as: external_react_.Fragment,
        children: /*#__PURE__*/jsx_runtime_.jsx(react_namespaceObject.Dialog, {
          as: "div",
          className: "flex overflow-y-scroll",
          onClose: setOpen,
          children: /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
            className: "h-screen overflow-y-scroll",
            children: [/*#__PURE__*/jsx_runtime_.jsx(react_namespaceObject.Transition.Child, {
              as: external_react_.Fragment,
              enter: "ease-in-out duration-500",
              enterFrom: "opacity-0",
              enterTo: "opacity-100",
              leave: "ease-in-out duration-500",
              leaveFrom: "opacity-100",
              leaveTo: "opacity-0",
              children: /*#__PURE__*/jsx_runtime_.jsx(react_namespaceObject.Dialog.Overlay, {
                className: " inset-0 bg-gray-500 bg-opacity-75 transition-opacity"
              })
            }), /*#__PURE__*/jsx_runtime_.jsx("div", {
              className: "fixed inset-y-0 right-0 w-screen flex",
              children: /*#__PURE__*/jsx_runtime_.jsx(react_namespaceObject.Transition.Child, {
                as: external_react_.Fragment,
                enter: "transform transition ease-in-out duration-500 sm:duration-700",
                enterFrom: "translate-y-full",
                enterTo: "translate-y-0",
                leave: "transform transition ease-in-out duration-500 sm:duration-700",
                leaveFrom: "translate-y-0",
                leaveTo: "translate-y-full",
                children: /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
                  className: "relative w-screen max-w-md",
                  children: [/*#__PURE__*/jsx_runtime_.jsx(react_namespaceObject.Transition.Child, {
                    as: external_react_.Fragment,
                    enter: "ease-in-out duration-500",
                    enterFrom: "opacity-0",
                    enterTo: "opacity-100",
                    leave: "ease-in-out duration-500",
                    leaveFrom: "opacity-100",
                    leaveTo: "opacity-0",
                    children: /*#__PURE__*/jsx_runtime_.jsx("div", {
                      className: "absolute "
                    })
                  }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
                    className: "fixed top-0 h-screen w-screen flex items-end",
                    children: [/*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
                      className: "absolute h-full w-full",
                      children: [selectedRoom === 1 && /*#__PURE__*/jsx_runtime_.jsx(ImageSlider/* default */.Z, {
                        images: [image1],
                        autoplay: false
                      }), selectedRoom === 2 && /*#__PURE__*/jsx_runtime_.jsx(ImageSlider/* default */.Z, {
                        images: [image2],
                        autoplay: false
                      })]
                    }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
                      className: " w-full bg-black flex flex-col opacity-95  space-y-4 ",
                      children: [/*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
                        className: "px-4  space-y-4  ",
                        children: [/*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
                          className: "flex mt-4",
                          children: [/*#__PURE__*/jsx_runtime_.jsx("h3", {
                            className: "uppercase font-mark text-2xl",
                            children: t.title
                          }), /*#__PURE__*/jsx_runtime_.jsx("div", {
                            onClick: openModal,
                            className: "flex justify-center items-center ml-auto",
                            children: /*#__PURE__*/jsx_runtime_.jsx("svg", {
                              width: "14",
                              height: "14",
                              viewBox: "0 0 14 14",
                              fill: "none",
                              xmlns: "http://www.w3.org/2000/svg",
                              children: /*#__PURE__*/jsx_runtime_.jsx("path", {
                                d: "M8.46 7L14 12.54V14H12.54L7 8.46L1.46 14H0V12.54L5.54 7L0 1.46V0H1.46L7 5.54L12.54 0H14V1.46L8.46 7Z",
                                fill: "white"
                              })
                            })
                          })]
                        }), /*#__PURE__*/jsx_runtime_.jsx(BookNow_RoomSelector, {
                          selectedRoom: selectedRoom,
                          setSelectedRoom: setSelectedRoom
                        }), /*#__PURE__*/jsx_runtime_.jsx(BookNow_DatePicker, {
                          startDate: startDate,
                          endDate: endDate,
                          setStartDate: setStartDate,
                          setEndDate: setEndDate
                        }), /*#__PURE__*/jsx_runtime_.jsx(BookNow_RoomsCount, {
                          count: countRooms,
                          setCount: setCountRooms
                        }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
                          className: "flex gap-2 justify-center gap ",
                          children: [/*#__PURE__*/jsx_runtime_.jsx(BookNow_Counter, {
                            categories: t.adult,
                            count: countAdults,
                            setCount: setCountAdults
                          }), /*#__PURE__*/jsx_runtime_.jsx(BookNow_Counter, {
                            categories: t.children,
                            count: countChildren,
                            setCount: setCountChildren
                          })]
                        })]
                      }), /*#__PURE__*/jsx_runtime_.jsx("div", {
                        className: "duration-1000 font-mark tracking-widest transition-all hover:bg-black hover:text-primary  text-white bg-primary min-w-full text-center text-2xl p-2",
                        children: /*#__PURE__*/jsx_runtime_.jsx("button", {
                          onClick: handleBookNow,
                          children: t.booknow
                        })
                      })]
                    })]
                  })]
                })
              })
            })]
          })
        })
      })]
    }), show && router.pathname === "/" && /*#__PURE__*/jsx_runtime_.jsx("div", {
      dir: locale === "ar" ? "rtl" : "ltl",
      className: "hidden lg:block",
      children: /*#__PURE__*/jsx_runtime_.jsx("div", {
        className: "fixed rtl:left-0 right-0 w-96 h-3/6 duration-1000 transition-all bottom-1/4 scale-100 ",
        children: /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
          className: "relative bg-black top-6 flex flex-col rounded-l-lg space-y-6 p-4 bg-opacity-75 ",
          children: [/*#__PURE__*/jsx_runtime_.jsx("h3", {
            className: "uppercase font-mark text-2xl",
            children: t.title
          }), /*#__PURE__*/jsx_runtime_.jsx(BookNow_RoomSelector, {
            selectedRoom: selectedRoom,
            setSelectedRoom: setSelectedRoom
          }), /*#__PURE__*/jsx_runtime_.jsx("div", {
            children: /*#__PURE__*/jsx_runtime_.jsx(BookNow_DatePicker, {
              startDate: startDate,
              endDate: endDate,
              setStartDate: setStartDate,
              setEndDate: setEndDate
            })
          }), /*#__PURE__*/jsx_runtime_.jsx(BookNow_RoomsCount, {
            count: countRooms,
            setCount: setCountRooms
          }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
            className: "flex gap-2 justify-center gap ",
            children: [/*#__PURE__*/jsx_runtime_.jsx(BookNow_Counter, {
              categories: t.adult,
              count: countAdults,
              setCount: setCountAdults
            }), /*#__PURE__*/jsx_runtime_.jsx(BookNow_Counter, {
              categories: t.children,
              count: countChildren,
              setCount: setCountChildren
            })]
          }), /*#__PURE__*/jsx_runtime_.jsx("div", {
            className: "transition duration-1000 hover:bg-black hover:text-primary hover:ring-1 hover:ring-primary  rounded-md text-white bg-primary min-w-full text-center text-2xl p-2",
            children: /*#__PURE__*/jsx_runtime_.jsx("button", {
              onClick: handleBookNow,
              children: t.booknow
            })
          })]
        })
      })
    }), !show && /*#__PURE__*/jsx_runtime_.jsx("div", {
      className: "lg:flex fixed bottom-0 min-w-full  bg-primary hidden ",
      children: /*#__PURE__*/jsx_runtime_.jsx(BookNow_ScrollBookNow, {})
    })]
  });
};

/* harmony default export */ const components_BookNow = (BookNow);
// EXTERNAL MODULE: ./node_modules/next/link.js
var next_link = __webpack_require__(1664);
;// CONCATENATED MODULE: ./components/NavBar/MobileMenuItem.tsx





const MobileMenuItem = props => {
  const router = (0,router_.useRouter)();

  const handleClick = () => {
    router.push("/" + props.id);
  };

  return /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
    onClick: handleClick,
    className: "flex p-3 ml-4 group transform transition-all duration-1000 hover:scale-95 ",
    children: [/*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
      className: "flex justify-center items-center  ",
      children: [/*#__PURE__*/jsx_runtime_.jsx("div", {
        className: " flex absolute items-center justify-center transition-all duration-1000 group-hover:rotate-90 ",
        children: IconsPack/* default.alsafirRings */.Z.alsafirRings
      }), /*#__PURE__*/jsx_runtime_.jsx("div", {
        className: "flex w-10 h-10 items-center justify-center",
        children: props.iconName
      })]
    }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
      className: "flex flex-col items-start pl-6  ",
      children: [/*#__PURE__*/jsx_runtime_.jsx("h5", {
        className: "text-2xl capitalize text-primary font-mark tracking-wider",
        children: props.menuTitle
      }), /*#__PURE__*/jsx_runtime_.jsx("p", {
        className: "text-sm text-white font-mark",
        children: props.menuDescription
      })]
    })]
  });
};

/* harmony default export */ const NavBar_MobileMenuItem = (MobileMenuItem);
// EXTERNAL MODULE: ./locales/navbar/en.ts
var navbar_en = __webpack_require__(4829);
// EXTERNAL MODULE: ./locales/navbar/ar.ts
var navbar_ar = __webpack_require__(5880);
// EXTERNAL MODULE: ./hooks/useTranslatiion.tsx
var useTranslatiion = __webpack_require__(3627);
;// CONCATENATED MODULE: ./components/NavBar/MobileMenu.tsx








const MobileMenu = () => {
  const t = (0,useTranslatiion/* default */.Z)(navbar_en/* default */.Z, navbar_ar/* default */.Z);
  return /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
    className: "pt-16",
    children: [/*#__PURE__*/jsx_runtime_.jsx(NavBar_MobileMenuItem, {
      id: "offers",
      iconName: IconsPack/* default.offerIcon */.Z.offerIcon,
      menuTitle: t.offers,
      menuDescription: "Get exclusive offers"
    }), /*#__PURE__*/jsx_runtime_.jsx(NavBar_MobileMenuItem, {
      id: "stay",
      iconName: IconsPack/* default.stayIcon */.Z.stayIcon,
      menuTitle: t.stay,
      menuDescription: "Ease and relax"
    }), /*#__PURE__*/jsx_runtime_.jsx(NavBar_MobileMenuItem, {
      id: "dine",
      iconName: IconsPack/* default.dineIcon */.Z.dineIcon,
      menuTitle: t.dine,
      menuDescription: "Dive into diversity"
    }), /*#__PURE__*/jsx_runtime_.jsx(NavBar_MobileMenuItem, {
      id: "entertainment",
      iconName: IconsPack/* default.entertainmentIcon */.Z.entertainmentIcon,
      menuTitle: t.entertainment,
      menuDescription: "Music never stops"
    }), /*#__PURE__*/jsx_runtime_.jsx(NavBar_MobileMenuItem, {
      id: "meet",
      iconName: IconsPack/* default.meetnEventIcon */.Z.meetnEventIcon,
      menuTitle: t.meet,
      menuDescription: "Conference"
    }), /*#__PURE__*/jsx_runtime_.jsx(NavBar_MobileMenuItem, {
      id: "health",
      iconName: IconsPack/* default.healthnWellnessIcon */.Z.healthnWellnessIcon,
      menuTitle: t.health,
      menuDescription: "Revive"
    }), /*#__PURE__*/jsx_runtime_.jsx(NavBar_MobileMenuItem, {
      id: "photogallery",
      iconName: IconsPack/* default.photoGallery */.Z.photoGallery,
      menuTitle: t.photogallery,
      menuDescription: "Experience"
    })]
  });
};

/* harmony default export */ const NavBar_MobileMenu = (MobileMenu);
;// CONCATENATED MODULE: ./components/NavBar/Contact.tsx



const Contact = () => {
  return /*#__PURE__*/jsx_runtime_.jsx("div", {
    className: "capitalize flex p-2  pl-6 w-full justify-start",
    children: /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
      className: " items-center ",
      children: [/*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
        className: " py-2",
        children: [/*#__PURE__*/jsx_runtime_.jsx("p", {
          className: "text-sm",
          children: "reservation number"
        }), /*#__PURE__*/jsx_runtime_.jsx("p", {
          className: "text-primary",
          children: /*#__PURE__*/jsx_runtime_.jsx("a", {
            href: "tel:+97317827999",
            children: "+973 1782 7999"
          })
        })]
      }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
        className: " py-2",
        children: [/*#__PURE__*/jsx_runtime_.jsx("p", {
          className: "text-sm",
          children: "whatsapp"
        }), /*#__PURE__*/jsx_runtime_.jsx("p", {
          className: "text-primary",
          children: /*#__PURE__*/jsx_runtime_.jsx("a", {
            href: "https://wa.me/+97333644411?text=I%20like%20to%20book%20rooms%20in%20AlSafir%20Hotel",
            children: "+973 33644411"
          })
        })]
      }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
        className: " py-2",
        children: [/*#__PURE__*/jsx_runtime_.jsx("p", {
          className: "text-sm",
          children: "email"
        }), /*#__PURE__*/jsx_runtime_.jsx("p", {
          className: "text-primary lowercase",
          children: /*#__PURE__*/jsx_runtime_.jsx("a", {
            href: "mailto:hello@alsafirhotel.com",
            children: "hello@alsafirhotel.com"
          })
        })]
      })]
    })
  });
};

/* harmony default export */ const NavBar_Contact = (Contact);
;// CONCATENATED MODULE: ./components/NavBar/index.tsx











const NavBar = () => {
  const router = (0,router_.useRouter)();
  const {
    locale
  } = router;
  const completeButtonRef = (0,external_react_.useRef)(null);
  const {
    0: openMenu,
    1: setOpenMenu
  } = (0,external_react_.useState)(false);

  const handleClick = () => {
    setOpenMenu(!openMenu);
  };

  const handleClose = () => {
    setOpenMenu(true);
  };

  const changeLanguage = e => {
    const locale = e.target.value;
    const {
      pathname
    } = router;
    router.push({
      pathname
    }, {
      pathname
    }, {
      locale
    });
  };

  const genericHamburgerLine = `h-1 w-10 my-1 bg-primary transition ease transform duration-300 `;
  return /*#__PURE__*/jsx_runtime_.jsx(jsx_runtime_.Fragment, {
    children: /*#__PURE__*/(0,jsx_runtime_.jsxs)("header", {
      className: "fixed w-full bg-black pl-4 z-10 flex justify-center items-center h-20",
      children: [/*#__PURE__*/jsx_runtime_.jsx(next_link.default, {
        href: "/",
        children: /*#__PURE__*/jsx_runtime_.jsx("a", {
          children: IconsPack/* default.alsfairLogo */.Z.alsfairLogo
        })
      }), /*#__PURE__*/jsx_runtime_.jsx("div", {
        className: "flex text-primary justify-center items-center ml-auto pr-4 space-x-4",
        children: /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
          onClick: handleClick,
          className: "flex items-center ml-2 uppercase space-x-2",
          children: [/*#__PURE__*/jsx_runtime_.jsx("label", {
            children: "Menu"
          }), /*#__PURE__*/jsx_runtime_.jsx("div", {
            onClick: handleClick,
            className: "scale-50",
            children: /*#__PURE__*/(0,jsx_runtime_.jsxs)("button", {
              className: "flex flex-col h-12 w-12  rounded justify-center items-center ",
              children: [/*#__PURE__*/jsx_runtime_.jsx("div", {
                className: `${genericHamburgerLine} ${openMenu ? "rotate-45 translate-y-3 opacity-100" : "opacity-100"}`
              }), /*#__PURE__*/jsx_runtime_.jsx("div", {
                className: `${genericHamburgerLine} ${openMenu ? "opacity-0" : "opacity-100"}`
              }), /*#__PURE__*/jsx_runtime_.jsx("div", {
                className: `${genericHamburgerLine} ${openMenu ? "-rotate-45 -translate-y-3 " : "opacity-100"}`
              })]
            })
          })]
        })
      }), /*#__PURE__*/jsx_runtime_.jsx(react_namespaceObject.Transition.Root, {
        show: openMenu,
        as: external_react_.Fragment,
        children: /*#__PURE__*/jsx_runtime_.jsx(react_namespaceObject.Dialog, {
          as: "div",
          className: "fixed inset-0 overflow-hidden",
          onClose: handleClose,
          initialFocus: completeButtonRef,
          children: /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
            className: "absolute inset-0 overflow-hidden",
            children: [/*#__PURE__*/jsx_runtime_.jsx(react_namespaceObject.Transition.Child, {
              as: external_react_.Fragment,
              enter: "ease-in-out duration-500",
              enterFrom: "opacity-0",
              enterTo: "opacity-100",
              leave: "ease-in-out duration-500",
              leaveFrom: "opacity-100",
              leaveTo: "opacity-0",
              children: /*#__PURE__*/jsx_runtime_.jsx(react_namespaceObject.Dialog.Overlay, {
                className: "absolute inset-0 bg-gray-500 bg-opacity-75 transition-opacity"
              })
            }), /*#__PURE__*/jsx_runtime_.jsx("div", {
              className: "fixed right-0 flex",
              children: /*#__PURE__*/jsx_runtime_.jsx(react_namespaceObject.Transition.Child, {
                as: external_react_.Fragment,
                enter: "transform transition ease-in-out duration-500 sm:duration-700",
                enterFrom: "translate-x-full",
                enterTo: "translate-x-0",
                leave: "transform transition ease-in-out duration-500 sm:duration-700",
                leaveFrom: "translate-x-0",
                leaveTo: "translate-x-full",
                children: /*#__PURE__*/jsx_runtime_.jsx("div", {
                  className: "flex flex-col h-auto bg-black shadow-xl overflow-y-scroll ",
                  children: /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
                    ref: completeButtonRef,
                    onClick: handleClick,
                    className: "pr-12 py-4 md:w-full w-screen h-screen rounded-md shadow-lg ",
                    children: [/*#__PURE__*/jsx_runtime_.jsx(NavBar_MobileMenu, {}), /*#__PURE__*/jsx_runtime_.jsx("div", {
                      className: "w-full capitalize h-12 border-b-2 border-primary text-white flex text-2xl justify-start pl-6 items-center",
                      children: /*#__PURE__*/jsx_runtime_.jsx("p", {
                        children: " Contact Us "
                      })
                    }), /*#__PURE__*/jsx_runtime_.jsx("div", {
                      className: "w-full  text-white flex text-2xl ",
                      children: /*#__PURE__*/jsx_runtime_.jsx(NavBar_Contact, {})
                    })]
                  })
                })
              })
            })]
          })
        })
      })]
    })
  });
};

/* harmony default export */ const components_NavBar = (NavBar);
// EXTERNAL MODULE: external "framer-motion"
var external_framer_motion_ = __webpack_require__(762);
;// CONCATENATED MODULE: external "next/script"
const script_namespaceObject = require("next/script");
var script_default = /*#__PURE__*/__webpack_require__.n(script_namespaceObject);
;// CONCATENATED MODULE: ./pages/_app.tsx
function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) { symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); } keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }











function MyApp({
  Component,
  pageProps,
  router
}) {
  const {
    locale
  } = router;
  return /*#__PURE__*/(0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
    children: [/*#__PURE__*/jsx_runtime_.jsx((script_default()), {
      strategy: "lazyOnload",
      src: `https://www.googletagmanager.com/gtag/js?id=${"G-KHM0QXC0BR"}`
    }), /*#__PURE__*/jsx_runtime_.jsx((script_default()), {
      strategy: "lazyOnload",
      children: `
        window.dataLayer = window.dataLayer || [];
        function gtag(){dataLayer.push(arguments);}
        gtag('js', new Date());
        gtag('config', '${"G-KHM0QXC0BR"}', {
        page_path: window.location.pathname,
        });
    `
    }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
      className: "flex flex-col h-screen ",
      children: [/*#__PURE__*/jsx_runtime_.jsx("header", {
        children: /*#__PURE__*/jsx_runtime_.jsx(components_NavBar, {})
      }), /*#__PURE__*/jsx_runtime_.jsx("main", {
        dir: locale === "ar" ? "rtl" : "ltl",
        className: "flex-1",
        children: /*#__PURE__*/jsx_runtime_.jsx(external_framer_motion_.AnimatePresence, {
          initial: false,
          exitBeforeEnter: true,
          children: /*#__PURE__*/(0,external_react_.createElement)(Component, _objectSpread(_objectSpread({}, pageProps), {}, {
            key: router.pathname
          }))
        })
      }), /*#__PURE__*/jsx_runtime_.jsx("footer", {
        className: "py-5 bg-black ",
        children: /*#__PURE__*/jsx_runtime_.jsx(components_BookNow, {})
      })]
    })]
  });
}

/* harmony default export */ const _app = (MyApp);

/***/ }),

/***/ 762:
/***/ ((module) => {

module.exports = require("framer-motion");

/***/ }),

/***/ 9325:
/***/ ((module) => {

module.exports = require("next/dist/server/denormalize-page-path.js");

/***/ }),

/***/ 8300:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/i18n/detect-domain-locale.js");

/***/ }),

/***/ 5378:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/i18n/normalize-locale-path.js");

/***/ }),

/***/ 7162:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/mitt.js");

/***/ }),

/***/ 8773:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router-context.js");

/***/ }),

/***/ 2248:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/get-asset-path-from-route.js");

/***/ }),

/***/ 9372:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/is-dynamic.js");

/***/ }),

/***/ 665:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/parse-relative-url.js");

/***/ }),

/***/ 2747:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/querystring.js");

/***/ }),

/***/ 333:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/route-matcher.js");

/***/ }),

/***/ 3456:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/route-regex.js");

/***/ }),

/***/ 7620:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/utils.js");

/***/ }),

/***/ 6731:
/***/ ((module) => {

module.exports = require("next/router");

/***/ }),

/***/ 9297:
/***/ ((module) => {

module.exports = require("react");

/***/ }),

/***/ 5282:
/***/ ((module) => {

module.exports = require("react/jsx-runtime");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [426,664,23,592,149], () => (__webpack_exec__(4332)));
module.exports = __webpack_exports__;

})();