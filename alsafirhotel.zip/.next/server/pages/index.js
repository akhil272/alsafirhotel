"use strict";
(() => {
var exports = {};
exports.id = 405;
exports.ids = [405];
exports.modules = {

/***/ 2631:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ pages),
  "getStaticProps": () => (/* binding */ getStaticProps)
});

// EXTERNAL MODULE: ./public/images/IconsPack.js
var IconsPack = __webpack_require__(5023);
// EXTERNAL MODULE: external "next/router"
var router_ = __webpack_require__(6731);
// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(5282);
;// CONCATENATED MODULE: ./components/Card/CardDetail.tsx





const CardDetail = props => {
  const router = (0,router_.useRouter)();

  const handleClick = () => {
    router.push("/" + props.id);
  };

  return /*#__PURE__*/jsx_runtime_.jsx("div", {
    onClick: handleClick,
    className: " lg:h-[375px] h-[220px] flex-shrink-0 bg-center bg-cover flex group  p-6 items-center hover:ml-10  opacity-90 hover:opacity-100 hover:shadow-2xl transition-all duration-1000 ease-in-out delay-200",
    style: {
      backgroundImage: `url(${props.image})`
    },
    children: /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
      id: "main-container",
      className: "flex flex-col items-start justify-start ",
      children: [/*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
        id: "alsafir-icon-container",
        className: "flex flex-row justify-start items-center ",
        children: [/*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
          id: "alsafir-icon",
          className: " ml-3 flex justify-center items-center",
          children: [props.icon, /*#__PURE__*/jsx_runtime_.jsx("div", {
            id: "alsafir-rings",
            className: "absolute h-50 w-50 transform transition-all duration-1000 group-hover:rotate-90 ",
            children: IconsPack/* default.alsafirRings */.Z.alsafirRings
          })]
        }), /*#__PURE__*/jsx_runtime_.jsx("div", {
          id: "alsafir-arrow",
          className: "ml-6 transform transition-all duration-1000 group-hover:scale-110 group-hover:ml-8 rtl:rotate-180 rtl:hover-rotate-90",
          children: IconsPack/* default.arrowIcon */.Z.arrowIcon
        })]
      }), /*#__PURE__*/jsx_runtime_.jsx("div", {
        id: "card title",
        className: "mt-2 ",
        children: /*#__PURE__*/jsx_runtime_.jsx("h3", {
          className: "text-primary uppercase font-markbook tracking-widest text-2xl lg:text-3xl",
          children: props.title
        })
      })]
    })
  });
};

/* harmony default export */ const Card_CardDetail = (CardDetail); // hover:ml-10 hover:shadow-2xl transition-all duration-1000 ease-in-out delay-200
// EXTERNAL MODULE: ./hooks/useTranslatiion.tsx
var useTranslatiion = __webpack_require__(3627);
// EXTERNAL MODULE: ./locales/navbar/en.ts
var en = __webpack_require__(4829);
// EXTERNAL MODULE: ./locales/navbar/ar.ts
var ar = __webpack_require__(5880);
;// CONCATENATED MODULE: ./components/Card/index.tsx








const Card = () => {
  const t = (0,useTranslatiion/* default */.Z)(en/* default */.Z, ar/* default */.Z);
  return /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
    children: [/*#__PURE__*/jsx_runtime_.jsx(Card_CardDetail, {
      id: "offers",
      icon: IconsPack/* default.offerIcon */.Z.offerIcon,
      title: t.offers,
      image: "/images/homepage/OffersCover.jpg"
    }), /*#__PURE__*/jsx_runtime_.jsx(Card_CardDetail, {
      id: "stay",
      icon: IconsPack/* default.stayIcon */.Z.stayIcon,
      title: t.stay,
      image: "/images/homepage/StayCover.jpg"
    }), /*#__PURE__*/jsx_runtime_.jsx(Card_CardDetail, {
      id: "dine",
      icon: IconsPack/* default.dineIcon */.Z.dineIcon,
      title: t.dine,
      image: "/images/homepage/DineInCover.jpg"
    }), /*#__PURE__*/jsx_runtime_.jsx(Card_CardDetail, {
      id: "entertainment",
      icon: IconsPack/* default.entertainmentIcon */.Z.entertainmentIcon,
      title: t.entertainment,
      image: "/images/homepage/entertainment-cover.jpg"
    }), /*#__PURE__*/jsx_runtime_.jsx(Card_CardDetail, {
      id: "meet",
      icon: IconsPack/* default.meetnEventIcon */.Z.meetnEventIcon,
      title: t.meet,
      image: "/images/homepage/meet-cover.jpg"
    }), /*#__PURE__*/jsx_runtime_.jsx(Card_CardDetail, {
      id: "health",
      icon: IconsPack/* default.healthnWellnessIcon */.Z.healthnWellnessIcon,
      title: t.health,
      image: "/images/homepage/health-cover.jpg"
    }), /*#__PURE__*/jsx_runtime_.jsx(Card_CardDetail, {
      id: "photogallery",
      icon: IconsPack/* default.photoGallery */.Z.photoGallery,
      title: t.photogallery,
      image: "/images/homepage/homeCover2.jpg"
    })]
  });
};

/* harmony default export */ const components_Card = (Card);
// EXTERNAL MODULE: ./components/ImageSlider/index.tsx
var ImageSlider = __webpack_require__(5592);
// EXTERNAL MODULE: external "next/head"
var head_ = __webpack_require__(701);
var head_default = /*#__PURE__*/__webpack_require__.n(head_);
;// CONCATENATED MODULE: ./locales/home/en.ts
/* harmony default export */ const home_en = ({
  subtitle: "Towers Residence Fitness",
  hero: "AL SAFIR HOTEL",
  location: "Manama, Bahrain",
  p1: `It is said that absolute luxury vests in minute particulars to give a heavenly experience. It involves competitive vision, ages preparing a craft and building reputation. Luxurious experience becomes a bequest. Al Safir, manifests a legacy in itself with the motive “service before self”. We take at most care and are upright for our customer service. This is the exact place where you experience paths of “Safirness”, a promise to make you lose your way and yet, find yourself to an unforgettable memory around the corner. The motivation for our customer service is our commitment to personal care and attention which you often find visiting friends and family. Relax your mind with stunning views, with the beauty of discovery, find the flow out of the beaches and fill your bags with luxury brand shopping.`,
  p2: "If you are looking for a royal stay then Al Safir Hotel is the place for you. The hotel assures you unbending comfort and convenience of a modern extravagant hotel without any compromise of its rare significant character. It is a gateway to a magnificent place located in right in Manama’s Juffair district, lllll. Adding to that, we offer exotic experience, soothing hospitality and a royal stay.Don’t blink twice to book because you deserve the best!"
});
;// CONCATENATED MODULE: ./locales/home/ar.ts
/* harmony default export */ const home_ar = ({
  subtitle: "أبراج ريزيدنس للياقة البدنية",
  hero: "فندق السفير",
  location: "منامة. البحرين",
  p1: `يقال أن سترات فاخرة مطلقة في تفاصيل دقيقة لإعطاء تجربة سماوية. إنه ينطوي على رؤية تنافسية ، وإعداد الأعمار للحرف وبناء السمعة. تصبح التجربة الفاخرة وصية. السفير ، يجسد إرثًا في حد ذاته بدافع "الخدمة قبل الذات". نحن نولي أقصى قدر من العناية ونكون مستقيمين لخدمة العملاء لدينا. هذا هو المكان المحدد الذي تختبر فيه مسارات "الأمان" ، وهو وعد سيجعلك تضيع طريقك ، ومع ذلك ، تجد نفسك في ذكرى لا تُنسى قاب قوسين أو أدنى. الدافع وراء خدمة العملاء لدينا هو التزامنا بالعناية الشخصية والاهتمام الذي غالبًا ما تجده عند زيارة الأصدقاء والعائلة. استرخي مع مناظر خلابة ، مع جمال الاكتشاف ، اكتشف التدفق من الشواطئ واملأ حقائبك بالتسوق من العلامات التجارية الفاخرة.`,
  p2: `إذا كنت تبحث عن إقامة ملكية ، فإن فندق السفير هو المكان المناسب لك. يضمن لك الفندق راحة وملاءمة لا حدود لها في فندق فخم حديث دون أي مساومة على طابعه الهام النادر. إنه بوابة إلى مكان رائع يقع في منطقة الجفير في المنامة ، lllll. إضافة إلى ذلك ، نحن نقدم تجربة رائعة ، وكرم الضيافة وإقامة ملكية. لا ترمش مرتين لتحجز لأنك تستحق الأفضل!`
});
// EXTERNAL MODULE: ./node_modules/next/link.js
var next_link = __webpack_require__(1664);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(9297);
;// CONCATENATED MODULE: ./components/Footer/ScrollToTop.tsx



function ScrollToTop() {
  const scrollToTop = () => {
    window.scrollTo({
      top: 0,
      behavior: "smooth"
    });
  };

  return /*#__PURE__*/jsx_runtime_.jsx("div", {
    className: "cursor-pointer",
    children: /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
      onClick: scrollToTop,
      className: " text-white flex items-center space-x-2 ",
      children: [/*#__PURE__*/jsx_runtime_.jsx("p", {
        children: "TOP"
      }), /*#__PURE__*/jsx_runtime_.jsx("svg", {
        width: "15",
        height: "10",
        viewBox: "0 0 15 10",
        fill: "none",
        xmlns: "http://www.w3.org/2000/svg",
        children: /*#__PURE__*/jsx_runtime_.jsx("path", {
          d: "M13.0463 9.63257L7.5 4.08632L1.95375 9.63257L0.25 7.91673L7.5 0.666734L14.75 7.91673L13.0463 9.63257Z",
          fill: "#BEA782"
        })
      })]
    })
  });
}
;// CONCATENATED MODULE: ./components/Footer/index.tsx





const Footer = () => {
  return /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
    className: "font-mark text-primary border-t-2 border-primary pt-2",
    children: [/*#__PURE__*/jsx_runtime_.jsx("div", {
      className: "px-4",
      children: /*#__PURE__*/jsx_runtime_.jsx(ScrollToTop, {})
    }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
      className: "uppercase flex justify-around",
      children: [/*#__PURE__*/jsx_runtime_.jsx(next_link.default, {
        href: "/contactus",
        children: /*#__PURE__*/jsx_runtime_.jsx("a", {
          children: "Contact Us"
        })
      }), /*#__PURE__*/jsx_runtime_.jsx(next_link.default, {
        href: "/faq",
        children: /*#__PURE__*/jsx_runtime_.jsx("a", {
          children: "FAQ"
        })
      }), /*#__PURE__*/jsx_runtime_.jsx(next_link.default, {
        href: "/privacypolicy",
        children: /*#__PURE__*/jsx_runtime_.jsx("a", {
          children: "Privacy Policy"
        })
      })]
    }), /*#__PURE__*/jsx_runtime_.jsx("div", {
      className: "my-4 uppercase flex justify-center",
      children: "@Alsafirhotel"
    })]
  });
};

/* harmony default export */ const components_Footer = (Footer);
;// CONCATENATED MODULE: ./pages/index.tsx










function Homepage({
  weather
}) {
  const t = (0,useTranslatiion/* default */.Z)(home_en, home_ar);
  const image1 = "/images/homepage/homeCoverImage01.jpg";
  const image2 = "/images/homepage/Inside-Al-Safir-Hotel.jpg";
  return /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
    children: [/*#__PURE__*/(0,jsx_runtime_.jsxs)((head_default()), {
      children: [/*#__PURE__*/jsx_runtime_.jsx("title", {
        children: "Al Safir Hotel | Experience luxury above all | Bahrain"
      }), /*#__PURE__*/jsx_runtime_.jsx("meta", {
        property: "og:title",
        content: "Al Safir Hotel | Experience luxury above all"
      }, "title"), /*#__PURE__*/jsx_runtime_.jsx("meta", {
        name: "description",
        content: "If you are looking for a royal stay then Al Safir Hotel is the place for you. a gateway to a magnificent place located in right in Manama\u2019s Juffair district"
      }), /*#__PURE__*/jsx_runtime_.jsx("link", {
        rel: "icon",
        href: "/favicon.ico"
      })]
    }), /*#__PURE__*/jsx_runtime_.jsx("div", {
      className: "h-screen w-full",
      children: /*#__PURE__*/jsx_runtime_.jsx(ImageSlider/* default */.Z, {
        images: [image1, image2],
        children: /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
          className: "bg-gradient-to-l from-transparent to-black rtl:bg-gradient-to-r flex flex-wrap content-end py-64 min-h-screen px-4",
          children: [/*#__PURE__*/jsx_runtime_.jsx("h1", {
            className: "text-primary font-brandon sm:w-1/2 tracking-widest text-6xl lg:text-8xl ",
            children: t.hero
          }), /*#__PURE__*/jsx_runtime_.jsx("div", {
            className: "min-w-full font-mark  lg:text-2xl",
            children: /*#__PURE__*/jsx_runtime_.jsx("h5", {
              children: t.subtitle
            })
          }), /*#__PURE__*/jsx_runtime_.jsx("div", {
            className: "text-secondary font-mark lg:text-lg",
            children: /*#__PURE__*/(0,jsx_runtime_.jsxs)("p", {
              children: [t.location, " :", /*#__PURE__*/(0,jsx_runtime_.jsxs)("span", {
                className: "pl-2",
                children: [Math.floor(weather.main.temp), " \xB0C"]
              })]
            })
          })]
        })
      })
    }), /*#__PURE__*/jsx_runtime_.jsx(components_Card, {}), /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
      className: "p-10 space-y-4 text-secondary",
      children: [/*#__PURE__*/jsx_runtime_.jsx("img", {
        src: "/images/AlsafirLogo.svg"
      }), /*#__PURE__*/jsx_runtime_.jsx("p", {
        children: t.p1
      }), /*#__PURE__*/jsx_runtime_.jsx("p", {
        children: t.p2
      })]
    }), /*#__PURE__*/jsx_runtime_.jsx(components_Footer, {})]
  });
}

/* harmony default export */ const pages = (Homepage);
const getStaticProps = async function () {
  const res = await fetch(`http://api.openweathermap.org/data/2.5/weather?q=Bahrain&units=metric&appid=${process.env.API_KEY}`);
  const data = await res.json();
  return {
    props: {
      weather: data
    }
  };
};

/***/ }),

/***/ 9325:
/***/ ((module) => {

module.exports = require("next/dist/server/denormalize-page-path.js");

/***/ }),

/***/ 8300:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/i18n/detect-domain-locale.js");

/***/ }),

/***/ 5378:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/i18n/normalize-locale-path.js");

/***/ }),

/***/ 7162:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/mitt.js");

/***/ }),

/***/ 8773:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router-context.js");

/***/ }),

/***/ 2248:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/get-asset-path-from-route.js");

/***/ }),

/***/ 9372:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/is-dynamic.js");

/***/ }),

/***/ 665:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/parse-relative-url.js");

/***/ }),

/***/ 2747:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/querystring.js");

/***/ }),

/***/ 333:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/route-matcher.js");

/***/ }),

/***/ 3456:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/route-regex.js");

/***/ }),

/***/ 7620:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/utils.js");

/***/ }),

/***/ 701:
/***/ ((module) => {

module.exports = require("next/head");

/***/ }),

/***/ 6731:
/***/ ((module) => {

module.exports = require("next/router");

/***/ }),

/***/ 9297:
/***/ ((module) => {

module.exports = require("react");

/***/ }),

/***/ 5282:
/***/ ((module) => {

module.exports = require("react/jsx-runtime");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [426,664,23,592,149], () => (__webpack_exec__(2631)));
module.exports = __webpack_exports__;

})();