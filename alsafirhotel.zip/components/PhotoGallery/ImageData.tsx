export const ImageData = [
  { id: 1, image: "/images/homepage/homeCoverImage01.jpg" },
  { id: 2, image: "/images/health/indoorpool.jpg" },
  { id: 3, image: "/images/homepage/Inside-Al-Safir-Hotel.jpg" },
  { id: 4, image: "/images/gallery/delux-twin.jpg" },
  { id: 5, image: "/images/staypage/single-room-alsafir-front-view.jpg" },
  { id: 6, image: "/images/staypage/twin-room-inside.jpg" },
];
